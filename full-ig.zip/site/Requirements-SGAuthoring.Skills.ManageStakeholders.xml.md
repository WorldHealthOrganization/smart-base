# Can manage stakeholders - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can manage stakeholders**

## : Can manage stakeholders - XML Representation

| |
| :--- |
| Draft as of 2026-11-19 |

[Raw xml](Requirements-SGAuthoring.Skills.ManageStakeholders.xml) | [Download](Requirements-SGAuthoring.Skills.ManageStakeholders.xml)

