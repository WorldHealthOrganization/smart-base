# Can author FHIR profiles - Testing - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author FHIR profiles**

## Requirements: Can author FHIR profiles - Testing (Experimental) 

| |
| :--- |
| Draft as of 2026-03-20 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

