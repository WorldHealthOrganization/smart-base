# Health Information Exchange / Interoperability Platform - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health Information Exchange / Interoperability Platform**

## : Health Information Exchange / Interoperability Platform - XML Representation

| |
| :--- |
| Draft as of 2026-03-20 |

[Raw xml](ActorDefinition-DAK.Persona.System.InteropPlatform.xml) | [Download](ActorDefinition-DAK.Persona.System.InteropPlatform.xml)

