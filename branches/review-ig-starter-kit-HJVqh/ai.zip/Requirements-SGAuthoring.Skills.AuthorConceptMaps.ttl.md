# Can author concept maps - TTL Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author concept maps**

## : Can author concept maps - TTL Representation

| |
| :--- |
| Draft as of 2026-03-20 |

[Raw ttl](Requirements-SGAuthoring.Skills.AuthorConceptMaps.ttl) | [Download](Requirements-SGAuthoring.Skills.AuthorConceptMaps.ttl)

