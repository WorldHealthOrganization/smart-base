# Can author FHIR profiles - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author FHIR profiles**

## : Can author FHIR profiles - XML Representation

| |
| :--- |
| Draft as of 2026-03-20 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorFHIRProfiles.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorFHIRProfiles.xml)

