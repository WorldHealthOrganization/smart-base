# Can author structure maps - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author structure maps**

## : Can author structure maps - XML Representation

| |
| :--- |
| Draft as of 2026-03-20 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorStructureMaps.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorStructureMaps.xml)

