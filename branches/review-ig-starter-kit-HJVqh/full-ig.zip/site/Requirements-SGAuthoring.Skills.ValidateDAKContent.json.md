# Can validate DAK content - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can validate DAK content**

## : Can validate DAK content - JSON Representation

| |
| :--- |
| Draft as of 2026-03-20 |

[Raw json](Requirements-SGAuthoring.Skills.ValidateDAKContent.json) | [Download](Requirements-SGAuthoring.Skills.ValidateDAKContent.json)

