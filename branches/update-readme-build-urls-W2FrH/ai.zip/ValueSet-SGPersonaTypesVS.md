# Smart Guidelines Persona Types Value Set - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Smart Guidelines Persona Types Value Set**

## ValueSet: Smart Guidelines Persona Types Value Set (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ValueSet/SGPersonaTypesVS | *Version*:0.2.0 |
| Active as of 2026-03-19 | *Computable Name*:SGPersonaTypesVS |

 
Value Set for Smart Guidelines Persona Section to autogenerate documentation from artifacts 

 **References** 

* [Persona (DAK)](StructureDefinition-Persona.md)
* [Persona (DAK)](StructureDefinition-Persona.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### Smart Guidelines Persona Types Value Set Schema API

JSON Schema for Smart Guidelines Persona Types Value Set ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-SGPersonaTypesVS.schema.json

#### JSON Schema definition for the enumeration ValueSet-SGPersonaTypesVS

This endpoint serves the JSON Schema definition for the enumeration ValueSet-SGPersonaTypesVS.

## Schema Definition

### ValueSet-SGPersonaTypesVS

**Description:** JSON Schema for Smart Guidelines Persona Types Value Set ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "SGPersonaTypesVS",
  "url" : "http://smart.who.int/base/ValueSet/SGPersonaTypesVS",
  "version" : "0.2.0",
  "name" : "SGPersonaTypesVS",
  "title" : "Smart Guidelines Persona Types Value Set",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-03-19T22:19:23+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Value Set for Smart Guidelines Persona Section to autogenerate documentation from artifacts",
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/base/CodeSystem/SGPersonaTypes"
    }]
  }
}

```
