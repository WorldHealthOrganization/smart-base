# Community Health Worker - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Community Health Worker**

## : Community Health Worker - TTL Representation

| |
| :--- |
| Draft as of 2026-08-19 |

[Raw ttl](ActorDefinition-DAK.Persona.CommunityHealthWorker.ttl) | [Download](ActorDefinition-DAK.Persona.CommunityHealthWorker.ttl)

