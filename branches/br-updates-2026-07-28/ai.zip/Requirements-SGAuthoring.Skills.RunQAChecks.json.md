# Can run QA checks - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can run QA checks**

## : Can run QA checks - JSON Representation

| |
| :--- |
| Draft as of 2026-08-19 |

[Raw json](Requirements-SGAuthoring.Skills.RunQAChecks.json) | [Download](Requirements-SGAuthoring.Skills.RunQAChecks.json)

