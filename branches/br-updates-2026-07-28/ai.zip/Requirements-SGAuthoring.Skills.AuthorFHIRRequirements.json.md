# Can author FHIR requirements - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author FHIR requirements**

## : Can author FHIR requirements - JSON Representation

| |
| :--- |
| Draft as of 2026-08-19 |

[Raw json](Requirements-SGAuthoring.Skills.AuthorFHIRRequirements.json) | [Download](Requirements-SGAuthoring.Skills.AuthorFHIRRequirements.json)

