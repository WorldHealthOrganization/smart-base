# Can author structure maps - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author structure maps**

## : Can author structure maps - JSON Representation

| |
| :--- |
| Draft as of 2026-08-19 |

[Raw json](Requirements-SGAuthoring.Skills.AuthorStructureMaps.json) | [Download](Requirements-SGAuthoring.Skills.AuthorStructureMaps.json)

