# Clinical Subject Matter Expert - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Clinical Subject Matter Expert**

## : Clinical Subject Matter Expert - XML Representation

| |
| :--- |
| Draft as of 2026-08-19 |

[Raw xml](ActorDefinition-SGAuthoring.Persona.ClinicalSME.xml) | [Download](ActorDefinition-SGAuthoring.Persona.ClinicalSME.xml)

