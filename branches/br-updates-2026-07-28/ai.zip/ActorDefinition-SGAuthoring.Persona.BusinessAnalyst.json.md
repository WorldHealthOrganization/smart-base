# Business Analyst - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Business Analyst**

## : Business Analyst - JSON Representation

| |
| :--- |
| Draft as of 2026-08-19 |

[Raw json](ActorDefinition-SGAuthoring.Persona.BusinessAnalyst.json) | [Download](ActorDefinition-SGAuthoring.Persona.BusinessAnalyst.json)

