# Resource SGAuthoring.Persona.TechnicalOfficer



## Resource Content

```json
{
  "resourceType" : "Basic",
  "id" : "SGAuthoring.Persona.TechnicalOfficer",
  "extension" : [{
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.url",
    "valueUri" : "http://smart.who.int/base/ActorDefinition/SGAuthoring.Persona.TechnicalOfficer"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.version",
    "valueString" : "0.3.0"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.name",
    "valueString" : "TechnicalOfficer"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.title",
    "valueString" : "Technical Officer"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.status",
    "valueCode" : "draft"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.experimental",
    "valueBoolean" : true
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.date",
    "valueDateTime" : "2026-08-19T05:31:39+00:00"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.publisher",
    "valueString" : "WHO"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.contact",
    "valueContactDetail" : {
      "name" : "WHO",
      "telecom" : [{
        "system" : "url",
        "value" : "http://who.int"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.description",
    "valueMarkdown" : "A health area technical officer who coordinates the work on the DAK and\nperforms first-pass review and validation of DAK content. Technical officers\nare part of the DAK development team and serve as the primary bridge between\nthe development team and the broader group of Subject Matter Experts.\n\nKey activities:\n- Coordinate DAK development work within the health programme area\n- Perform first-pass review of drafted DAK components\n- Validate that components accurately reflect L1 recommendations\n- Identify gaps, ambiguities, and alternatives in DAK content\n- Prepare agendas and questions for SME consultation meetings\n- Ensure content is software-neutral and context-appropriate\n- Spread awareness of SMART Guidelines within the department\n\n**Source**: IG Starter Kit, L2 DAK Authoring, Section 2.2 \"Validate DAK content with SMEs\""
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.jurisdiction"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.type",
    "valueCode" : "person"
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/fhir-types",
      "code" : "ActorDefinition"
    }]
  }
}

```
