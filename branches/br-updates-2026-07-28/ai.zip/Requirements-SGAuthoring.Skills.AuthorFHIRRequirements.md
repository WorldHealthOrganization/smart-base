# Can author FHIR requirements - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author FHIR requirements**

## Requirements: Can author FHIR requirements (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorFHIRRequirements | *Version*:0.3.0 |
| Draft as of 2026-08-19 | *Computable Name*:SkillAuthorFHIRRequirements |

 
Capability to create FHIR Requirements resources from L2 functional and non-functional requirements. 

