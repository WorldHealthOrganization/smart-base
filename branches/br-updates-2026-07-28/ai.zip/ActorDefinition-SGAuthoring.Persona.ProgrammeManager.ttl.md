# Programme Manager - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Programme Manager**

## : Programme Manager - TTL Representation

| |
| :--- |
| Draft as of 2026-08-19 |

[Raw ttl](ActorDefinition-SGAuthoring.Persona.ProgrammeManager.ttl) | [Download](ActorDefinition-SGAuthoring.Persona.ProgrammeManager.ttl)

