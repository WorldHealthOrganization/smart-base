# Can author decision-support logic - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author decision-support logic**

## : Can author decision-support logic - TTL Representation

| |
| :--- |
| Draft as of 2026-08-19 |

[Raw ttl](Requirements-SGAuthoring.Skills.AuthorDecisionLogic.ttl) | [Download](Requirements-SGAuthoring.Skills.AuthorDecisionLogic.ttl)

