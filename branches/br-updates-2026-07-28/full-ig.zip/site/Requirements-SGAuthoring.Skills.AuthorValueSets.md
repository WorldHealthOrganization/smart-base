# Can author value sets - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author value sets**

## Requirements: Can author value sets (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorValueSets | *Version*:0.3.0 |
| Draft as of 2026-08-19 | *Computable Name*:SkillAuthorValueSets |

 
Capability to create and maintain FHIR ValueSet resources with appropriate terminology bindings. 

