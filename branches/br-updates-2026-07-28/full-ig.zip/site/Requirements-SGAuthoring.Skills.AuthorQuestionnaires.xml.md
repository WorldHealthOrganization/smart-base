# Can author questionnaires - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author questionnaires**

## : Can author questionnaires - XML Representation

| |
| :--- |
| Draft as of 2026-08-19 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorQuestionnaires.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorQuestionnaires.xml)

