# Client Registry / Master Patient Index - Testing - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Client Registry / Master Patient Index**

## ActorDefinition: Client Registry / Master Patient Index - Testing (Experimental) 

| |
| :--- |
| Draft as of 2026-10-20 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

