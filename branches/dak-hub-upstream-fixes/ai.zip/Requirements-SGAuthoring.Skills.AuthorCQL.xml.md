# Can author CQL - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author CQL**

## : Can author CQL - XML Representation

| |
| :--- |
| Draft as of 2026-10-20 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorCQL.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorCQL.xml)

