# FHIR Modeller - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FHIR Modeller**

## : FHIR Modeller - JSON Representation

| |
| :--- |
| Draft as of 2026-10-20 |

[Raw json](ActorDefinition-SGAuthoring.Persona.FHIRModeller.json) | [Download](ActorDefinition-SGAuthoring.Persona.FHIRModeller.json)

