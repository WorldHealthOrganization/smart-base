# Can manage stakeholders - TTL Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can manage stakeholders**

## : Can manage stakeholders - TTL Representation

| |
| :--- |
| Draft as of 2026-04-01 |

[Raw ttl](Requirements-SGAuthoring.Skills.ManageStakeholders.ttl) | [Download](Requirements-SGAuthoring.Skills.ManageStakeholders.ttl)

