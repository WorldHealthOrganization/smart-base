# Can interpret clinical recommendations - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can interpret clinical recommendations**

## Requirements: Can interpret clinical recommendations (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.InterpretClinicalRecommendations | *Version*:0.2.0 |
| Draft as of 2026-04-01 | *Computable Name*:SkillInterpretClinicalRecommendations |

 
Capability to interpret clinical recommendations from L1 source documents with domain expertise. 

