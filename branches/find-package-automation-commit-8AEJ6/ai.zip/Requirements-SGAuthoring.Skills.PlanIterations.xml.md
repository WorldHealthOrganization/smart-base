# Can plan iterations - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can plan iterations**

## : Can plan iterations - XML Representation

| |
| :--- |
| Draft as of 2026-04-01 |

[Raw xml](Requirements-SGAuthoring.Skills.PlanIterations.xml) | [Download](Requirements-SGAuthoring.Skills.PlanIterations.xml)

