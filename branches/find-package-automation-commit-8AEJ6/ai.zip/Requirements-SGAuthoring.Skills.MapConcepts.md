# Can map concepts - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can map concepts**

## Requirements: Can map concepts (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.MapConcepts | *Version*:0.2.0 |
| Draft as of 2026-04-01 | *Computable Name*:SkillMapConcepts |

 
Capability to map data elements to WHO Commons dictionary, ICD-11, SNOMED CT, LOINC, and other standard terminologies. 

