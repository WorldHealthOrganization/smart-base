# Can author indicators - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author indicators**

## : Can author indicators - JSON Representation

| |
| :--- |
| Draft as of 2026-04-01 |

[Raw json](Requirements-SGAuthoring.Skills.AuthorIndicators.json) | [Download](Requirements-SGAuthoring.Skills.AuthorIndicators.json)

