# FHIR Modeller - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FHIR Modeller**

## : FHIR Modeller - JSON Representation

| |
| :--- |
| Draft as of 2026-04-01 |

[Raw json](ActorDefinition-SGAuthoring.Persona.FHIRModeller.json) | [Download](ActorDefinition-SGAuthoring.Persona.FHIRModeller.json)

