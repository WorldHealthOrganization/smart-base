# Services and Application Types: Point of Service - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Services and Application Types: Point of Service**

## ValueSet: Services and Application Types: Point of Service (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ValueSet/CDSCv2.A | *Version*:0.2.0 |
| Active as of 2026-04-01 | *Computable Name*:CDSCv2.A |

 
Systems that facilitate the provision and delivery of healthcare services to persons at the point of care. Group A of the Classification of Digital Health Services and Application Types v2 (CDISAH, 2023). 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### Services and Application Types: Point of Service Schema API

JSON Schema for Services and Application Types: Point of Service ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-CDSCv2.A.schema.json

#### JSON Schema definition for the enumeration ValueSet-CDSCv2.A

This endpoint serves the JSON Schema definition for the enumeration ValueSet-CDSCv2.A.

## Schema Definition

### ValueSet-CDSCv2.A

**Description:** JSON Schema for Services and Application Types: Point of Service ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "CDSCv2.A",
  "url" : "http://smart.who.int/base/ValueSet/CDSCv2.A",
  "version" : "0.2.0",
  "name" : "CDSCv2.A",
  "title" : "Services and Application Types: Point of Service",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-04-01T14:08:18+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Systems that facilitate the provision and delivery of healthcare services to persons at the point of care. Group A of the Classification of Digital Health Services and Application Types v2 (CDISAH, 2023).",
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/base/CodeSystem/CDSCv2",
      "concept" : [{
        "code" : "A"
      },
      {
        "code" : "A1"
      },
      {
        "code" : "A2"
      },
      {
        "code" : "A3"
      },
      {
        "code" : "A4"
      },
      {
        "code" : "A5"
      },
      {
        "code" : "A6"
      },
      {
        "code" : "A7"
      },
      {
        "code" : "A8"
      },
      {
        "code" : "A9"
      }]
    }]
  }
}

```
