# FHIR Modeller - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FHIR Modeller**

## : FHIR Modeller - XML Representation

| |
| :--- |
| Draft as of 2026-04-01 |

[Raw xml](ActorDefinition-SGAuthoring.Persona.FHIRModeller.xml) | [Download](ActorDefinition-SGAuthoring.Persona.FHIRModeller.xml)

