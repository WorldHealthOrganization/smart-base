# Can scope DAK - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can scope DAK**

## : Can scope DAK - XML Representation

| |
| :--- |
| Draft as of 2026-04-01 |

[Raw xml](Requirements-SGAuthoring.Skills.ScopeDAK.xml) | [Download](Requirements-SGAuthoring.Skills.ScopeDAK.xml)

