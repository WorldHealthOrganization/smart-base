# Can author FHIR requirements - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author FHIR requirements**

## Requirements: Can author FHIR requirements (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorFHIRRequirements | *Version*:0.2.0 |
| Draft as of 2026-04-01 | *Computable Name*:SkillAuthorFHIRRequirements |

 
Capability to create FHIR Requirements resources from L2 functional and non-functional requirements. 

