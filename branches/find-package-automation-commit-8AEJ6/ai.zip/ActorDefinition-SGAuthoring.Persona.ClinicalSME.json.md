# Clinical Subject Matter Expert - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Clinical Subject Matter Expert**

## : Clinical Subject Matter Expert - JSON Representation

| |
| :--- |
| Draft as of 2026-04-01 |

[Raw json](ActorDefinition-SGAuthoring.Persona.ClinicalSME.json) | [Download](ActorDefinition-SGAuthoring.Persona.ClinicalSME.json)

