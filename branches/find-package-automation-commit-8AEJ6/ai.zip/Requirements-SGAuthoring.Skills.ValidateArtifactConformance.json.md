# Can validate artifact conformance - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can validate artifact conformance**

## : Can validate artifact conformance - JSON Representation

| |
| :--- |
| Draft as of 2026-04-01 |

[Raw json](Requirements-SGAuthoring.Skills.ValidateArtifactConformance.json) | [Download](Requirements-SGAuthoring.Skills.ValidateArtifactConformance.json)

