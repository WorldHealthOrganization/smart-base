# Public Health and Disease Surveillance System - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Public Health and Disease Surveillance System**

## : Public Health and Disease Surveillance System - JSON Representation

| |
| :--- |
| Draft as of 2026-03-24 |

[Raw json](ActorDefinition-DAK.Persona.System.SurveillanceSystem.json) | [Download](ActorDefinition-DAK.Persona.System.SurveillanceSystem.json)

