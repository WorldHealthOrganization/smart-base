# Community Health Worker - Testing - SMART Base v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Community Health Worker**

## ActorDefinition: Community Health Worker - Testing (Experimental) 

| |
| :--- |
| Draft as of 2026-08-27 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

