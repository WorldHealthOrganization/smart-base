# Core Data Element Type Value Set - SMART Base v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Core Data Element Type Value Set**

## ValueSet: Core Data Element Type Value Set 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ValueSet/CoreDataElementTypeVS | *Version*:1.0.0 |
| Active as of 2026-08-27 | *Computable Name*:CoreDataElementTypeVS |

 
Value set of core data element types 

 **References** 

* [Core Data Element (DAK)](StructureDefinition-CoreDataElement.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### Core Data Element Type Value Set Schema API

JSON Schema for Core Data Element Type Value Set ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-CoreDataElementTypeVS.schema.json

#### JSON Schema definition for the enumeration ValueSet-CoreDataElementTypeVS

This endpoint serves the JSON Schema definition for the enumeration ValueSet-CoreDataElementTypeVS.

## Schema Definition

### ValueSet-CoreDataElementTypeVS

**Description:** JSON Schema for Core Data Element Type Value Set ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "CoreDataElementTypeVS",
  "url" : "http://smart.who.int/base/ValueSet/CoreDataElementTypeVS",
  "version" : "1.0.0",
  "name" : "CoreDataElementTypeVS",
  "title" : "Core Data Element Type Value Set",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-27T08:21:50+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Value set of core data element types",
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/base/CodeSystem/CoreDataElementType"
    }]
  }
}

```
