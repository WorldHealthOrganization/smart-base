# Can map concepts - JSON Representation - SMART Base v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can map concepts**

## : Can map concepts - JSON Representation

| |
| :--- |
| Draft as of 2026-08-27 |

[Raw json](Requirements-SGAuthoring.Skills.MapConcepts.json) | [Download](Requirements-SGAuthoring.Skills.MapConcepts.json)

