# Can translate content - XML Representation - SMART Base v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can translate content**

## : Can translate content - XML Representation

| |
| :--- |
| Draft as of 2026-08-27 |

[Raw xml](Requirements-SGAuthoring.Skills.TranslateContent.xml) | [Download](Requirements-SGAuthoring.Skills.TranslateContent.xml)

