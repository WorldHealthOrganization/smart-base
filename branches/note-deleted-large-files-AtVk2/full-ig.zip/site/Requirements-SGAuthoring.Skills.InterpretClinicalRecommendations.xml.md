# Can interpret clinical recommendations - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can interpret clinical recommendations**

## : Can interpret clinical recommendations - XML Representation

| |
| :--- |
| Draft as of 2026-03-23 |

[Raw xml](Requirements-SGAuthoring.Skills.InterpretClinicalRecommendations.xml) | [Download](Requirements-SGAuthoring.Skills.InterpretClinicalRecommendations.xml)

