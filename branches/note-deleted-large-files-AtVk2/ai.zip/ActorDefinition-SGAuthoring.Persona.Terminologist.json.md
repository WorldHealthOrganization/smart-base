# Terminologist - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Terminologist**

## : Terminologist - JSON Representation

| |
| :--- |
| Draft as of 2026-03-23 |

[Raw json](ActorDefinition-SGAuthoring.Persona.Terminologist.json) | [Download](ActorDefinition-SGAuthoring.Persona.Terminologist.json)

