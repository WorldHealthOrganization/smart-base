# Classification of Digital Health Interventions v2 - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Classification of Digital Health Interventions v2**

## ValueSet: Classification of Digital Health Interventions v2 (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ValueSet/CDHIv2 | *Version*:0.2.0 |
| Active as of 2026-03-23 | *Computable Name*:CDHIv2 |

 
Value Set for the Classification of Digital Interventions, Services and Applications in Health (CDISAH), second edition (2023). 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### Classification of Digital Health Interventions v2 Schema API

JSON Schema for Classification of Digital Health Interventions v2 ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-CDHIv2.schema.json

#### JSON Schema definition for the enumeration ValueSet-CDHIv2

This endpoint serves the JSON Schema definition for the enumeration ValueSet-CDHIv2.

## Schema Definition

### ValueSet-CDHIv2

**Description:** JSON Schema for Classification of Digital Health Interventions v2 ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "CDHIv2",
  "url" : "http://smart.who.int/base/ValueSet/CDHIv2",
  "version" : "0.2.0",
  "name" : "CDHIv2",
  "title" : "Classification of Digital Health Interventions v2",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-03-23T14:03:33+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Value Set for the Classification of Digital Interventions, Services and Applications in Health (CDISAH), second edition (2023).",
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/base/CodeSystem/CDHIv2"
    }]
  }
}

```
