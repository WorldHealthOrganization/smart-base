# Translator - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Translator**

## ActorDefinition: Translator (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ActorDefinition/SGAuthoring.Persona.Translator | *Version*:0.3.0 |
| Draft as of 2026-11-19 | *Computable Name*:Translator |

 
A language specialist responsible for translating SMART Guidelines Implementation Guide content across UN languages to support global adoption and adaptation. 
Key activities: 
* Translate IG narrative content across UN languages
* Translate FHIR resource display names and descriptions
* Review translated content for accuracy and clinical correctness
* Manage .pot/.po translation template files
* Coordinate with clinical SMEs for domain-specific terminology
* Ensure translated examples are available for each non-abstract profile
 
**Source**: IG Starter Kit, Checklist L4 (example resources per UN language); PR 288 translation skill infrastructure 

