# Can build IG - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can build IG**

## : Can build IG - TTL Representation

| |
| :--- |
| Draft as of 2026-11-19 |

[Raw ttl](Requirements-SGAuthoring.Skills.BuildIG.ttl) | [Download](Requirements-SGAuthoring.Skills.BuildIG.ttl)

