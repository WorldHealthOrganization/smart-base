# Can author business processes - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author business processes**

## Requirements: Can author business processes (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorBusinessProcesses | *Version*:0.3.0 |
| Draft as of 2026-11-19 | *Computable Name*:SkillAuthorBusinessProcesses |

 
Capability to create BPMN 2.0 business process diagrams for DAK workflows. 

