# Quality Control Reviewer - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Quality Control Reviewer**

## : Quality Control Reviewer - XML Representation

| |
| :--- |
| Draft as of 2026-11-19 |

[Raw xml](ActorDefinition-SGAuthoring.Persona.QCReviewer.xml) | [Download](ActorDefinition-SGAuthoring.Persona.QCReviewer.xml)

