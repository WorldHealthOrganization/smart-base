# Can interpret clinical recommendations - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can interpret clinical recommendations**

## : Can interpret clinical recommendations - XML Representation

| |
| :--- |
| Draft as of 2026-11-19 |

[Raw xml](Requirements-SGAuthoring.Skills.InterpretClinicalRecommendations.xml) | [Download](Requirements-SGAuthoring.Skills.InterpretClinicalRecommendations.xml)

