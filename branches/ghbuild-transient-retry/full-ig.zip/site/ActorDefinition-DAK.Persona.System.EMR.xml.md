# Electronic Medical Record (EMR) System - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Electronic Medical Record (EMR) System**

## : Electronic Medical Record (EMR) System - XML Representation

| |
| :--- |
| Draft as of 2026-11-19 |

[Raw xml](ActorDefinition-DAK.Persona.System.EMR.xml) | [Download](ActorDefinition-DAK.Persona.System.EMR.xml)

