# Person (Health Service User) - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Person (Health Service User)**

## : Person (Health Service User) - JSON Representation

| |
| :--- |
| Draft as of 2026-11-19 |

[Raw json](ActorDefinition-DAK.Persona.Person.json) | [Download](ActorDefinition-DAK.Persona.Person.json)

