# Can author code systems - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author code systems**

## : Can author code systems - XML Representation

| |
| :--- |
| Draft as of 2026-11-19 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorCodeSystems.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorCodeSystems.xml)

