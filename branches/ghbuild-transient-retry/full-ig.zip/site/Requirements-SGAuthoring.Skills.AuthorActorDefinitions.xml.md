# Can author actor definitions - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author actor definitions**

## : Can author actor definitions - XML Representation

| |
| :--- |
| Draft as of 2026-11-19 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorActorDefinitions.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorActorDefinitions.xml)

