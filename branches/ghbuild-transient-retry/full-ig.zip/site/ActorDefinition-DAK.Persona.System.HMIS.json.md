# Health Management Information System (HMIS) - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health Management Information System (HMIS)**

## : Health Management Information System (HMIS) - JSON Representation

| |
| :--- |
| Draft as of 2026-11-19 |

[Raw json](ActorDefinition-DAK.Persona.System.HMIS.json) | [Download](ActorDefinition-DAK.Persona.System.HMIS.json)

