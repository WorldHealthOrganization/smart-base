# Changes - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* **Changes**

## Changes

### Version 1.0.0

Initial Release

