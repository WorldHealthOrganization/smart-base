# Health System Manager - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health System Manager**

## : Health System Manager - XML Representation

| |
| :--- |
| Draft as of 2026-09-07 |

[Raw xml](ActorDefinition-DAK.Persona.HealthSystemManager.xml) | [Download](ActorDefinition-DAK.Persona.HealthSystemManager.xml)

