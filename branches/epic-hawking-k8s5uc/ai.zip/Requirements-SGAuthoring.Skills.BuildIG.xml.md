# Can build IG - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can build IG**

## : Can build IG - XML Representation

| |
| :--- |
| Draft as of 2026-10-26 |

[Raw xml](Requirements-SGAuthoring.Skills.BuildIG.xml) | [Download](Requirements-SGAuthoring.Skills.BuildIG.xml)

