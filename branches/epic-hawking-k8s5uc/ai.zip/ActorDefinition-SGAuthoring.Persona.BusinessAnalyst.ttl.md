# Business Analyst - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Business Analyst**

## : Business Analyst - TTL Representation

| |
| :--- |
| Draft as of 2026-10-26 |

[Raw ttl](ActorDefinition-SGAuthoring.Persona.BusinessAnalyst.ttl) | [Download](ActorDefinition-SGAuthoring.Persona.BusinessAnalyst.ttl)

