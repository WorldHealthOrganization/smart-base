# Healthcare Provider - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Healthcare Provider**

## : Healthcare Provider - XML Representation

| |
| :--- |
| Draft as of 2026-10-26 |

[Raw xml](ActorDefinition-DAK.Persona.HealthcareProvider.xml) | [Download](ActorDefinition-DAK.Persona.HealthcareProvider.xml)

