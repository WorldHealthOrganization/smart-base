# Can review and approve content - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can review and approve content**

## : Can review and approve content - XML Representation

| |
| :--- |
| Draft as of 2026-10-26 |

[Raw xml](Requirements-SGAuthoring.Skills.ReviewAndApproveContent.xml) | [Download](Requirements-SGAuthoring.Skills.ReviewAndApproveContent.xml)

