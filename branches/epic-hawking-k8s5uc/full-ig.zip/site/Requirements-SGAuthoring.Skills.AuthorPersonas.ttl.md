# Can author personas - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author personas**

## : Can author personas - TTL Representation

| |
| :--- |
| Draft as of 2026-10-26 |

[Raw ttl](Requirements-SGAuthoring.Skills.AuthorPersonas.ttl) | [Download](Requirements-SGAuthoring.Skills.AuthorPersonas.ttl)

