# Can scope DAK - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can scope DAK**

## Requirements: Can scope DAK (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.ScopeDAK | *Version*:0.3.0 |
| Draft as of 2026-10-26 | *Computable Name*:SkillScopeDAK |

 
Capability to define DAK scope, identify source documents, and establish the development process and governance. 

