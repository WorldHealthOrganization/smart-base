# Electronic Medical Record (EMR) System - Testing - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Electronic Medical Record (EMR) System**

## ActorDefinition: Electronic Medical Record (EMR) System - Testing (Experimental) 

| |
| :--- |
| Draft as of 2026-10-26 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

