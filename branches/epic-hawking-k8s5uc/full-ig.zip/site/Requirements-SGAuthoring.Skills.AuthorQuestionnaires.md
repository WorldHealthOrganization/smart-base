# Can author questionnaires - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author questionnaires**

## Requirements: Can author questionnaires (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorQuestionnaires | *Version*:0.3.0 |
| Draft as of 2026-10-26 | *Computable Name*:SkillAuthorQuestionnaires |

 
Capability to create FHIR Questionnaire resources aligned with L2 forms and data collection needs. 

