# Can author CQL - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author CQL**

## Requirements: Can author CQL (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorCQL | *Version*:0.3.0 |
| Draft as of 2026-10-26 | *Computable Name*:SkillAuthorCQL |

 
Capability to write Clinical Quality Language (CQL) for decision logic, scheduling logic, and indicator calculations. 

