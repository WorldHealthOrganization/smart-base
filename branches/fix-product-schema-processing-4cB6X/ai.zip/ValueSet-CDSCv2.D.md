# Services and Application Types: Data Management Services - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Services and Application Types: Data Management Services**

## ValueSet: Services and Application Types: Data Management Services (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ValueSet/CDSCv2.D | *Version*:0.2.0 |
| Active as of 2026-03-19 | *Computable Name*:CDSCv2.D |

 
Services and systems that support the collection, aggregation, storage, analysis, and exchange of health data. Group D of the Classification of Digital Health Services and Application Types v2 (CDISAH, 2023). 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### Services and Application Types: Data Management Services Schema API

JSON Schema for Services and Application Types: Data Management Services ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-CDSCv2.D.schema.json

#### JSON Schema definition for the enumeration ValueSet-CDSCv2.D

This endpoint serves the JSON Schema definition for the enumeration ValueSet-CDSCv2.D.

## Schema Definition

### ValueSet-CDSCv2.D

**Description:** JSON Schema for Services and Application Types: Data Management Services ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "CDSCv2.D",
  "url" : "http://smart.who.int/base/ValueSet/CDSCv2.D",
  "version" : "0.2.0",
  "name" : "CDSCv2.D",
  "title" : "Services and Application Types: Data Management Services",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-03-19T23:43:34+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Services and systems that support the collection, aggregation, storage, analysis, and exchange of health data. Group D of the Classification of Digital Health Services and Application Types v2 (CDISAH, 2023).",
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/base/CodeSystem/CDSCv2",
      "concept" : [{
        "code" : "D"
      },
      {
        "code" : "D1"
      },
      {
        "code" : "D2"
      },
      {
        "code" : "D3"
      },
      {
        "code" : "D4"
      },
      {
        "code" : "D5"
      },
      {
        "code" : "D6"
      },
      {
        "code" : "D7"
      },
      {
        "code" : "D8"
      }]
    }]
  }
}

```
