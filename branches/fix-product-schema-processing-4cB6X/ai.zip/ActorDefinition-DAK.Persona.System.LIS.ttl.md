# Laboratory Information System (LIS) - TTL Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Laboratory Information System (LIS)**

## : Laboratory Information System (LIS) - TTL Representation

| |
| :--- |
| Draft as of 2026-03-19 |

[Raw ttl](ActorDefinition-DAK.Persona.System.LIS.ttl) | [Download](ActorDefinition-DAK.Persona.System.LIS.ttl)

