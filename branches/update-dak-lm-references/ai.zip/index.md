# Home - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ImplementationGuide/smart.who.int.base | *Version*:0.2.0 |
| Draft as of 2025-10-09 | *Computable Name*:Base |

### Overview

This implementation guide contains base conformance resources for use in all WHO SMART Guidelines implementation guides.

See the [SMART IG Starter Kit](https://smart.who.int/ig-starter-kit/) for more information on building and using WHO SMART Guidelines.

### Dependencies

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (smart.who.int.base.r4)](package.r4.tgz) and [R4B (smart.who.int.base.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* © International Labour Organization 2008

* [International Standard Classification of Occupations 2008](CodeSystem-ISCO08.md): [GenericPersona](StructureDefinition-GenericPersona.md) and [ISCO08ValueSet](ValueSet-ISCO08ValueSet.md)


