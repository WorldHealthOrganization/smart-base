# Home - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ImplementationGuide/smart.who.int.base | *Version*:0.3.0 |
| Draft as of 2026-11-23 | *Computable Name*:Base |

### Overview

**WHO SMART Guidelines** (Standards-based, Machine-readable, Adaptive, Requirements-based, and Testable) are a set of WHO clinical guidelines that have been transformed into a computable, interoperable format. They enable countries to rapidly adopt, adapt, and implement WHO recommendations within their digital health systems by providing structured, machine-readable clinical content.

A **Digital Adaptation Kit (DAK)** is the primary artefact of WHO SMART Guidelines. It is a structured, standardised package of clinical and operational content that represents a WHO health intervention in a computable form. Each DAK contains:

* **Health interventions and recommendations** – the clinical guidance from WHO
* **Generic personas** – representative end-users and actors in the health system
* **User scenarios** – narrative descriptions of how the guidance is used in practice
* **Business processes and workflows** – step-by-step care pathways
* **Core data elements** – the data dictionary for the health domain
* **Decision-support logic** – computable clinical decision rules
* **Functional and non-functional requirements** – system capability requirements
* **Program indicators** – aggregate measures and metrics for monitoring and evaluation
* **Test scenarios** – structured tests to validate conformance

The diagram below illustrates the nine components of a WHO DAK and how they relate to one another:

Figure 1 – The nine components of a WHO Digital Adaptation Kit (DAK)
This implementation guide contains base conformance resources for use in all WHO SMART Guidelines implementation guides.

### Authoring Lifecycle

The DAK authoring lifecycle is a five-phase process spanning planning, L2 DAK authoring, L3 FHIR authoring, quality control, and publication. The BPMN 2.0 collaboration diagram below shows the end-to-end process with swimlanes for each [authoring persona](authoring-personas.md).

Figure 2 – DAK Authoring Lifecycle (BPMN 2.0). See
[Authoring Process](authoring-process.md)for details.
See the [SMART IG Starter Kit](https://smart.who.int/ig-starter-kit/) for more information on building and using WHO SMART Guidelines.

### DAK (Digital Adaptation Kit) URL Handling

For repositories whose root `index.config.json` declares a DAK (a `dak` section under `contentTypes`; formerly a `dak.json` file), this implementation guide provides enhanced URL handling for publication and preview scenarios:

#### Publication URLs

* **WHO Repositories**: For repositories owned by `WorldHealthOrganization`, the publication URL follows the pattern `https://smart.who.int/{stub}` where `{stub}` is the repository name with any `smart-` prefix removed.
* **Other Repositories**: Use the canonical URL specified in `sushi-config.yaml` or fall back to GitHub Pages pattern.

#### Preview URLs

* **All Repositories**: Preview URLs use the GitHub Pages pattern `https://{profile}.github.io/{repo}` for current CI builds.

#### Branch-Based URL Selection

* **Release Branches** (prefixed with `release-`): Use publication URLs for canonical references and resource identifiers.
* **Development Branches**: Use preview URLs for canonical references and resource identifiers.

The DAK configuration is automatically regenerated during CI builds to ensure URLs are appropriate for the current branch context.

### Dependencies

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (smart.who.int.base.r4)](package.r4.tgz) and [R4B (smart.who.int.base.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* © International Labour Organization 2008

* [International Standard Classification of Occupations 2008](CodeSystem-ISCO08.md): [GenericPersona](StructureDefinition-GenericPersona.md) and [ISCO08ValueSet](ValueSet-ISCO08ValueSet.md)


* WHO © 2023. Some rights reserved. CC BY-NC-SA 3.0 IGO.

* [Classification of Digital Health Interventions v2](CodeSystem-CDHIv2.md): [CDHIv2](ValueSet-CDHIv2.md), [CDHIv2.1](ValueSet-CDHIv2.1.md), [CDHIv2.2](ValueSet-CDHIv2.2.md), [CDHIv2.3](ValueSet-CDHIv2.3.md) and [CDHIv2.4](ValueSet-CDHIv2.4.md)
* [Classification of Digital Health Services and Application Types v2](CodeSystem-CDSCv2.md): [CDSCv2](ValueSet-CDSCv2.md), [CDSCv2.A](ValueSet-CDSCv2.A.md)... Show 4 more, [CDSCv2.B](ValueSet-CDSCv2.B.md), [CDSCv2.C](ValueSet-CDSCv2.C.md), [CDSCv2.D](ValueSet-CDSCv2.D.md) and [CDSCv2.E](ValueSet-CDSCv2.E.md)




## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "smart.who.int.base",
  "meta" : {
    "profile" : ["http://smart.who.int/base/StructureDefinition/SGImplementationGuide"]
  },
  "url" : "http://smart.who.int/base/ImplementationGuide/smart.who.int.base",
  "version" : "0.3.0",
  "name" : "Base",
  "title" : "SMART Base",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-11-23T18:43:35+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Base SMART Guidelines implementation guide to be used as the base dependency for all SMART Guidelines IGs",
  "packageId" : "smart.who.int.base",
  "license" : "CC-BY-SA-3.0-IGO",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7_terminology",
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology",
    "version" : "7.3.0"
  },
  {
    "id" : "hl7_fhir_uv_extensions_r4",
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "cql",
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.dependsOn.reason",
      "valueMarkdown" : "This IG uses CQL profiles and capabilities provided by the Using CQL With FHIR IG"
    }],
    "uri" : "http://hl7.org/fhir/uv/cql/ImplementationGuide/hl7.fhir.uv.cql",
    "packageId" : "hl7.fhir.uv.cql",
    "version" : "2.0.0"
  },
  {
    "id" : "cpg",
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.dependsOn.reason",
      "valueMarkdown" : "For Decision Tables"
    }],
    "uri" : "http://hl7.org/fhir/uv/cpg/ImplementationGuide/hl7.fhir.uv.cpg",
    "packageId" : "hl7.fhir.uv.cpg",
    "version" : "2.0.0"
  },
  {
    "id" : "crmi",
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.dependsOn.reason",
      "valueMarkdown" : "This IG uses content management profiles and capabilities provided by the Canonical Resource Management Infrastructure (CRMI) IG"
    }],
    "uri" : "http://hl7.org/fhir/uv/crmi/ImplementationGuide/hl7.fhir.uv.crmi",
    "packageId" : "hl7.fhir.uv.crmi",
    "version" : "2.0.0"
  },
  {
    "id" : "sdc",
    "extension" : [{
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.dependsOn.reason",
      "valueMarkdown" : "This IG uses questionnaire profiles and capabilities provided by the Structure Data Capture (SDC) IG"
    }],
    "uri" : "http://hl7.org/fhir/uv/sdc/ImplementationGuide/hl7.fhir.uv.sdc",
    "packageId" : "hl7.fhir.uv.sdc",
    "version" : "4.0.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2023+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "fr"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "ar"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "zh"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "ru"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "es"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid-ig"
      },
      {
        "url" : "value",
        "valueString" : "templates/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://smart.who.int/base/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "grouping" : [{
      "id" : "Conformance",
      "name" : "Conformance",
      "description" : "constraints and profile structures for SMART Guidelines resources"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.BusinessAnalyst.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.BusinessAnalyst"
      },
      "name" : "Business Analyst",
      "description" : "A digital health informatician specializing in business analysis who authors\nL2 DAK components. Business analysts translate clinical guidelines and\nnormative products into structured DAK artifacts including business processes,\ndata dictionaries, decision-support logic, and requirements.\n\nKey activities:\n- Review L1 source documents and extract structured content\n- Author generic personas based on task-shifting guidelines\n- Create user scenario narratives\n- Design BPMN 2.0 business process diagrams\n- Define core data elements and data dictionary\n- Develop decision-support logic tables (DMN standard)\n- Develop scheduling logic tables\n- Define indicators and performance metrics\n- Capture functional and non-functional requirements\n- Streamline content across DAK components for consistency\n\n**Source**: IG Starter Kit, L2 DAK Authoring, Section 2.1 \"Fill in DAK components\";\nCommunity of Practice page",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BusinessProcessWorkflow.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BusinessProcessWorkflow"
      },
      "name" : "Business Process Workflow (DAK)",
      "description" : "Logical Model for representing Generic Business Processes and Workflows from a DAK. A business process is a set of related activities or tasks performed together to achieve the objectives of the health programme area.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BusinessProcessWorkflowSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BusinessProcessWorkflowSource"
      },
      "name" : "Business Process Workflow Source",
      "description" : "Source reference for Business Process Workflow - exactly one of the following must be provided:\n- url (url data type): URL to retrieve BusinessProcessWorkflow definition from input/ or external source\n- canonical (canonical data type): Canonical URI pointing to the BusinessProcessWorkflow definition\n- instance: Inline BusinessProcessWorkflow instance data",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorActorDefinitions.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorActorDefinitions"
      },
      "name" : "Can author actor definitions",
      "description" : "Capability to create FHIR ActorDefinitions from L2 personas, reusing existing definitions from the Commons repository.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorBusinessProcesses.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorBusinessProcesses"
      },
      "name" : "Can author business processes",
      "description" : "Capability to create BPMN 2.0 business process diagrams for DAK workflows.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorCodeSystems.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorCodeSystems"
      },
      "name" : "Can author code systems",
      "description" : "Capability to create and maintain FHIR CodeSystem resources.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorConceptMaps.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorConceptMaps"
      },
      "name" : "Can author concept maps",
      "description" : "Capability to create FHIR ConceptMap resources for cross-terminology mappings.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorCQL.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorCQL"
      },
      "name" : "Can author CQL",
      "description" : "Capability to write Clinical Quality Language (CQL) for decision logic, scheduling logic, and indicator calculations.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorDataDictionary.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorDataDictionary"
      },
      "name" : "Can author data dictionary",
      "description" : "Capability to define core data elements and map to standard terminologies.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorDecisionLogic.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorDecisionLogic"
      },
      "name" : "Can author decision-support logic",
      "description" : "Capability to develop decision-support logic tables following the DMN standard.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorExampleScenarios.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorExampleScenarios"
      },
      "name" : "Can author example scenarios",
      "description" : "Capability to create ExampleScenario resources from L2 user scenarios.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorFHIRProfiles.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorFHIRProfiles"
      },
      "name" : "Can author FHIR profiles",
      "description" : "Capability to create FHIR profiles (StructureDefinitions) constraining base FHIR resources.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorFHIRRequirements.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorFHIRRequirements"
      },
      "name" : "Can author FHIR requirements",
      "description" : "Capability to create FHIR Requirements resources from L2 functional and non-functional requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorFunctionalRequirements.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorFunctionalRequirements"
      },
      "name" : "Can author functional requirements",
      "description" : "Capability to define high-level functional and non-functional requirements linked to personas and business processes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorIndicators.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorIndicators"
      },
      "name" : "Can author indicators",
      "description" : "Capability to define indicators and performance metrics with numerator/denominator specifications.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorLogicalModels.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorLogicalModels"
      },
      "name" : "Can author logical models",
      "description" : "Capability to create FHIR logical models (StructureDefinitions) from L2 data dictionaries.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorMeasures.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorMeasures"
      },
      "name" : "Can author measures",
      "description" : "Capability to create FHIR Measure resources from L2 indicators.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorPersonas.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorPersonas"
      },
      "name" : "Can author personas",
      "description" : "Capability to define generic personas based on task-shifting guidelines and ground-truthing interviews.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorPlanDefinitions.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorPlanDefinitions"
      },
      "name" : "Can author plan definitions",
      "description" : "Capability to create FHIR PlanDefinitions for business processes and decision tables.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorQuestionnaires.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorQuestionnaires"
      },
      "name" : "Can author questionnaires",
      "description" : "Capability to create FHIR Questionnaire resources aligned with L2 forms and data collection needs.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorSchedulingLogic.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorSchedulingLogic"
      },
      "name" : "Can author scheduling logic",
      "description" : "Capability to develop scheduling logic tables following the DMN standard.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorStructureMaps.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorStructureMaps"
      },
      "name" : "Can author structure maps",
      "description" : "Capability to create FHIR StructureMaps for data extraction from QuestionnaireResponses to FHIR resources.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorTestCases.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorTestCases"
      },
      "name" : "Can author test cases",
      "description" : "Capability to create TestPlan, TestScript, and example instances for validation of L3 artifacts.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorUserScenarios.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorUserScenarios"
      },
      "name" : "Can author user scenarios",
      "description" : "Capability to create user scenario narratives depicting typical interactions in health programme workflows.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.AuthorValueSets.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.AuthorValueSets"
      },
      "name" : "Can author value sets",
      "description" : "Capability to create and maintain FHIR ValueSet resources with appropriate terminology bindings.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.BuildIG.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.BuildIG"
      },
      "name" : "Can build IG",
      "description" : "Capability to run the FHIR IG Publisher build process and verify output.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ConfigureIG.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ConfigureIG"
      },
      "name" : "Can configure IG",
      "description" : "Capability to set up and configure a FHIR Implementation Guide (sushi-config, canonical URL, packages).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.InterpretClinicalRecommendations.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.InterpretClinicalRecommendations"
      },
      "name" : "Can interpret clinical recommendations",
      "description" : "Capability to interpret clinical recommendations from L1 source documents with domain expertise.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ManageGovernance.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ManageGovernance"
      },
      "name" : "Can manage governance",
      "description" : "Capability to manage cross-IG governance for shared artifacts including common personas, terminology, and libraries.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ManageReleases.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ManageReleases"
      },
      "name" : "Can manage releases",
      "description" : "Capability to manage versioning, publication-request.json, release tags, and publication workflow.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ManageStakeholders.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ManageStakeholders"
      },
      "name" : "Can manage stakeholders",
      "description" : "Capability to engage SMEs, coordinate consultations, and manage the RASCI matrix for DAK development.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.MapConcepts.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.MapConcepts"
      },
      "name" : "Can map concepts",
      "description" : "Capability to map data elements to WHO Commons dictionary, ICD-11, SNOMED CT, LOINC, and other standard terminologies.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.PlanIterations.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.PlanIterations"
      },
      "name" : "Can plan iterations",
      "description" : "Capability to plan sprint iterations, maintain the DAK backlog, draft the project roadmap, and facilitate retrospectives.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ReviewAndApproveContent.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ReviewAndApproveContent"
      },
      "name" : "Can review and approve content",
      "description" : "Capability to review and formally approve SMART Guidelines content at decision gates in the authoring lifecycle.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ReviewChecklist.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ReviewChecklist"
      },
      "name" : "Can review checklist",
      "description" : "Capability to review the SMART Guidelines publication checklist across L1-L4 layers and global requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ReviewL1Guidelines.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ReviewL1Guidelines"
      },
      "name" : "Can review L1 guidelines",
      "description" : "Capability to review WHO L1 narrative guidelines and normative products for accuracy and completeness.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ReviewTerminology.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ReviewTerminology"
      },
      "name" : "Can review terminology",
      "description" : "Capability to review and validate terminology bindings, code systems, and value sets for correctness and completeness.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ReviewTranslations.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ReviewTranslations"
      },
      "name" : "Can review translations",
      "description" : "Capability to review translated content for accuracy and completeness.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.RunQAChecks.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.RunQAChecks"
      },
      "name" : "Can run QA checks",
      "description" : "Capability to run and interpret IG Publisher QA validation reports.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ScopeDAK.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ScopeDAK"
      },
      "name" : "Can scope DAK",
      "description" : "Capability to define DAK scope, identify source documents, and establish the development process and governance.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.TranslateContent.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.TranslateContent"
      },
      "name" : "Can translate content",
      "description" : "Capability to translate IG content across UN languages.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ValidateArtifactConformance.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ValidateArtifactConformance"
      },
      "name" : "Can validate artifact conformance",
      "description" : "Capability to verify conformance to CRMI Shareable, Publishable, Computable, and Executable profiles.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ValidateDAKContent.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ValidateDAKContent"
      },
      "name" : "Can validate DAK content",
      "description" : "Capability to review and validate DAK components against L1 source documents and for cross-component consistency.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Requirements-SGAuthoring.Skills.ValidateL3Functionality.html"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ImplementationGuide.definition.resource.profile",
        "valueCanonical" : "http://smart.who.int/base/StructureDefinition/SGRequirements"
      }],
      "reference" : {
        "reference" : "Requirements/SGAuthoring.Skills.ValidateL3Functionality"
      },
      "name" : "Can validate L3 functionality",
      "description" : "Capability to test StructureMap extraction, CQL execution, and measure calculation using reference tooling.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv1.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv1"
      },
      "name" : "Classification of Digital Health Interventions v1",
      "description" : "Value Set for Classification of Digital Health Interventions v1. Autogenerated from DAK artifacts",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CDHIv1.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CDHIv1"
      },
      "name" : "Classification of Digital Health Interventions v1",
      "description" : "CodeSystem for Classification of Digital Health Interventions v1. Autogenerated from DAK artifacts",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv2.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv2"
      },
      "name" : "Classification of Digital Health Interventions v2",
      "description" : "Value Set for the Classification of Digital Interventions, Services and Applications in Health (CDISAH), second edition (2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CDHIv2.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CDHIv2"
      },
      "name" : "Classification of Digital Health Interventions v2",
      "description" : "CodeSystem for the Classification of Digital Interventions, Services and Applications in Health\n(CDISAH), second edition (2023). ISBN 978-92-4-008194-9.\n\nOrganised into four groups based on the primary user:\n  1. Persons\n  2. Healthcare providers\n  3. Health management and support personnel\n  4. Data services\n\nNew categories vs v1: 1.4.4, 1.6.2, 1.8, 2.5.6, 2.11, 3.1.5, 3.5.7, 3.5.8, 3.8, 4.3.5, 4.4.2, 4.4.3, 4.5.\nSee ConceptMap CDHIv1toCDHIv2 for the full mapping from the first edition.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CDSCv2.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CDSCv2"
      },
      "name" : "Classification of Digital Health Services and Application Types v2",
      "description" : "CodeSystem for the Classification of Digital Health Services and Application Types v2,\nas defined in the Classification of Digital Interventions, Services and Applications in Health\n(CDISAH), second edition (2023). ISBN 978-92-4-008194-9.\n\nServices and Application Types represent the types of software, ICT systems and services\nor communication channels that deliver or execute digital health interventions (DHIs) and\nhealth content.\n\nThe types are organised into five representations within the Digital Health Architecture:\n  A. Point of service\n  B. Health system/Provider administration\n  C. Registries and Directories\n  D. Data Management services\n  E. Surveillance and Response",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CDSCv1.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CDSCv1"
      },
      "name" : "Classification of Digital Health System Categories v1",
      "description" : "CodeSystem for Classification of Digital Health System Categories v1. Autogenerated from DAK artifacts",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.ClinicalSME.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.ClinicalSME"
      },
      "name" : "Clinical Subject Matter Expert",
      "description" : "A clinician or subject matter expert (SME) of a specific health area who\nvalidates the clinical accuracy and completeness of DAK content against\nWHO guidelines and other normative products. SMEs should be the authors\nof the source documents or recognized experts actively engaged in, if not\nleading, the collaborative development of the DAKs.\n\nKey activities:\n- Validate that DAK components accurately reflect L1 recommendations\n- Provide clinical ground-truthing through country visits and interviews\n- Identify gaps or needed changes in DAK content\n- Review decision-support logic for clinical correctness\n- Confirm that workflows represent 80% of clinical scenarios\n- Validate personas against real-world practice settings\n- Advise on cross-programme overlaps (e.g. TB/HIV indicators)\n\n**Source**: IG Starter Kit, L2 DAK Authoring, Sections 1 \"Plan\" and 2.2 \"Validate\"",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-DAK.Persona.CommunityHealthWorker.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/DAK.Persona.CommunityHealthWorker"
      },
      "name" : "Community Health Worker",
      "description" : "A frontline member of the health workforce who delivers health interventions\nat the community level, acting as a link between communities and formal health\nfacilities. Community health workers are a key sub-group of healthcare providers.\n\nCommunity health workers use DHIs to:\n- Register and follow-up community members (2.1, 2.2.1)\n- Receive community-based decision support and job aids (2.3)\n- Report public health events from point of diagnosis (3.3.1)\n- Access mobile training and competency assessments (2.8)\n- Communicate with supervising clinical staff (2.5.1)\n- Manage their daily visit planning and activities (2.7)\n\n**ISCO-08**: 3255 (Community health workers), 5321 (Health care assistants).\n\n**Examples**: Village health worker, health extension worker, community health\nvolunteer, lay health advisor, peer educator, traditional birth attendant,\ncommunity case manager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.ContentReviewer.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.ContentReviewer"
      },
      "name" : "Content Reviewer / Approver",
      "description" : "A designated reviewer responsible for approving SMART Guidelines content\nat key decision gates in the authoring lifecycle. Content Reviewers ensure\nthat DAK and IG content meets quality standards, accurately reflects WHO\nnormative guidance, and is ready to proceed to the next phase.\n\nContent Reviewers may be senior technical officers, programme leads, or\ndesignated governance committee members. They provide formal sign-off at\nphase transitions (L2→L3, draft→publication).\n\nKey activities:\n- Review and approve L2 DAK content before L3 authoring begins\n- Review and approve L3 IG content before publication\n- Assess whether content changes are breaking or non-breaking\n- Approve draft publications for stakeholder circulation\n- Provide final sign-off for release publication\n- Ensure content aligns with WHO guidelines governance policies\n- Participate in cross-programme content harmonization reviews\n\n**Source**: IG Starter Kit, Publication page (review process);\nDAK Authoring, Section 2.2 \"Validate DAK content with SMEs\"",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-CoreDataElement.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CoreDataElement"
      },
      "name" : "Core Data Element (DAK)",
      "description" : "Logical Model for representing Core Data Elements from a DAK. A core data element can be one of: a ValueSet, a CodeSystem, a ConceptMap, or a Logical Model adherent to SGLogicalModel. This is the ONE EXCEPTION to allowing FHIR R4 models into the DAK LMs.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-CoreDataElementSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CoreDataElementSource"
      },
      "name" : "Core Data Element Source",
      "description" : "Source reference for Core Data Element - exactly one of the following must be provided:\n- url (url data type): URL to retrieve CoreDataElement definition from input/ or external source\n- canonical (canonical data type): Canonical URI pointing to the CoreDataElement definition\n- instance: Inline CoreDataElement instance data",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-CoreDataElementType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/CoreDataElementType"
      },
      "name" : "Core Data Element Type",
      "description" : "CodeSystem for Core Data Element types - defines the type of FHIR resource that a Core Data Element references.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CoreDataElementTypeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CoreDataElementTypeVS"
      },
      "name" : "Core Data Element Type Value Set",
      "description" : "Value set of core data element types",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DecisionSupportLogicSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DecisionSupportLogicSource"
      },
      "name" : "Decision Support Logic Source",
      "description" : "Source reference for Decision Support Logic - exactly one of the following must be provided:\n- url (url data type): URL to retrieve DecisionSupportLogic definition from input/ or external source\n- canonical (canonical data type): Canonical URI pointing to the DecisionSupportLogic definition\n- instance: Inline DecisionSupportLogic instance data",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DecisionSupportLogic.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DecisionSupportLogic"
      },
      "name" : "Decision-Support Logic (DAK)",
      "description" : "Logical Model for representing Decision-Support Logic from a DAK. Decision-support logic and algorithms to support appropriate service delivery in accordance with WHO clinical, public health and data use guidelines.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DAK.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DAK"
      },
      "name" : "Digital Adaptation Kit (DAK)",
      "description" : "Logical Model for representing a complete Digital Adaptation Kit (DAK) with metadata and all 9 DAK components",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv1.1.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv1.1"
      },
      "name" : "Digital Health Interventions for Clients",
      "description" : "Digital Health Interventions whose primary user group is Clients (persons using health services). Group 1 of the Classification of Digital Health Interventions v1 (2018).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv2.3.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv2.3"
      },
      "name" : "Digital Health Interventions for Health Management and Support Personnel",
      "description" : "Digital Health Interventions whose primary user group is Health Management and Support Personnel. Group 3 of the Classification of Digital Interventions, Services and Applications in Health v2 (CDISAH, 2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv1.3.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv1.3"
      },
      "name" : "Digital Health Interventions for Health System Managers",
      "description" : "Digital Health Interventions whose primary user group is Health System Managers. Group 3 of the Classification of Digital Health Interventions v1 (2018).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv1.2.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv1.2"
      },
      "name" : "Digital Health Interventions for Health Workers",
      "description" : "Digital Health Interventions whose primary user group is Health Workers. Group 2 of the Classification of Digital Health Interventions v1 (2018).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv2.2.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv2.2"
      },
      "name" : "Digital Health Interventions for Healthcare Providers",
      "description" : "Digital Health Interventions whose primary user group is Healthcare Providers. Group 2 of the Classification of Digital Interventions, Services and Applications in Health v2 (CDISAH, 2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv2.1.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv2.1"
      },
      "name" : "Digital Health Interventions for Persons",
      "description" : "Digital Health Interventions whose primary user group is Persons (health service users). Group 1 of the Classification of Digital Interventions, Services and Applications in Health v2 (CDISAH, 2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv1.4.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv1.4"
      },
      "name" : "Digital Health Interventions: Data Services",
      "description" : "Crosscutting Data Services DHIs. Group 4 of the Classification of Digital Health Interventions v1 (2018).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDHIv2.4.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDHIv2.4"
      },
      "name" : "Digital Health Interventions: Data Services",
      "description" : "Crosscutting Data Services DHIs. Group 4 of the Classification of Digital Interventions, Services and Applications in Health v2 (CDISAH, 2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DublinCore.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DublinCore"
      },
      "name" : "Dublin Core Metadata Element Set",
      "description" : "Logical Model representing Dublin Core metadata elements as defined at https://www.dublincore.org/specifications/dublin-core/dcmi-terms/",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.FHIRModeller.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.FHIRModeller"
      },
      "name" : "FHIR Modeller",
      "description" : "An L3 author who creates machine-readable FHIR artifacts from L2 DAK\nspecifications. FHIR Modellers use FSH (FHIR Shorthand), SUSHI, and\nthe IG Publisher toolchain to produce conformant Implementation Guides.\n\nKey activities:\n- Verify L2 input availability and consistency\n- Author FHIR Logical Models from L2 data dictionaries\n- Create FHIR Profiles (StructureDefinitions)\n- Author FHIR Questionnaires from L2 forms\n- Write CQL for decision logic, scheduling logic, and indicators\n- Create StructureMaps for data extraction\n- Author PlanDefinitions for business processes and decision tables\n- Create ActorDefinitions from L2 personas (reusing Commons repository)\n- Create ExampleScenario resources from L2 user scenarios\n- Author FHIR Measure resources from L2 indicators\n- Create FHIR Requirements resources\n- Develop test cases (TestPlan, TestScript, example instances)\n- Ensure all artifacts conform to CRMI Shareable/Publishable profiles\n\n**Source**: IG Starter Kit, L2-L3 Overview and all L3 authoring pages",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-FHIRSchemaBase.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/FHIRSchemaBase"
      },
      "name" : "FHIR Schema Base (SMART Guidelines)",
      "description" : "Base logical model providing the common schema metadata interface inherited by all SMART Guidelines logical models. Every SMART Guidelines logical model schema derives from this base, which documents the shared FHIR and JSON-LD metadata properties used by the JSON Schema generation pipeline.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-Requirements.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Requirements"
      },
      "name" : "Functional and Non-Functional Requirements (DAK)",
      "description" : "Logical Model for representing Functional and Non-Functional Requirements from a DAK. A high-level list of core functions and capabilities that the system must have to meet the end users' needs.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-FunctionalRequirement.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/FunctionalRequirement"
      },
      "name" : "Functional Requirement (DAK)",
      "description" : "Logical Model for representing functional requirement from a DAK",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-GenericPersona.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/GenericPersona"
      },
      "name" : "Generic Persona (DAK)",
      "description" : "Logical Model for representing Generic Personas from a DAK. Depiction of the human and system actors. Human actors are end users, supervisors and related stakeholders who would be interacting with the digital system or involved in the clinical care, public health or health system pathway.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-GenericPersonaSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/GenericPersonaSource"
      },
      "name" : "Generic Persona Source",
      "description" : "Source reference for Generic Persona - exactly one of the following must be provided:\n- url (url data type): URL to retrieve GenericPersona definition from input/ or external source\n- canonical (canonical data type): Canonical URI pointing to the GenericPersona definition\n- instance: Inline GenericPersona instance data",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-DAK.Persona.DataManager.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/DAK.Persona.DataManager"
      },
      "name" : "Health Data Manager and Analyst",
      "description" : "A professional who manages, analyses, and disseminates health data to support\nevidence-based decision-making. This corresponds to the 'Data services' user\ngroup in CDISAH v2, providing crosscutting functionality across the health system.\n\nData managers use DHIs to:\n- Create data collection forms and manage data acquisition (4.1.1)\n- Store and aggregate health data (4.1.2)\n- Synthesise and visualise data for reporting and dashboards (4.1.3)\n- Apply automated analytics and predictive modelling including AI/ML (4.1.4)\n- Parse, de-duplicate, and curate coded datasets and terminologies (4.2)\n- Classify disease codes and causes of mortality (4.2.3)\n- Map geographic locations of facilities, events, populations, and providers (4.3)\n- Enable point-to-point data integration and standards-compliant interoperability (4.4)\n- Maintain data governance including authentication, privacy, and consent (4.5)\n\n**ISCO-08**: 2120 (Mathematicians, actuaries and statisticians), 2521 (Database\ndesigners and administrators), 2523 (Computer network professionals), 3120\n(Computer network and systems technicians).\n\n**Examples**: Biostatistician, epidemiologist, health informatician, data analyst,\nDHIS2 administrator, GIS specialist, interoperability engineer, terminology manager.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-HealthInterventions.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/HealthInterventions"
      },
      "name" : "Health Interventions and Recommendations (DAK)",
      "description" : "Logical Model for representing Health Interventions and Recommendations from a DAK. Overview of the health interventions and WHO, regional or national recommendations included within the DAK.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-HealthInterventionsSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/HealthInterventionsSource"
      },
      "name" : "Health Interventions Source",
      "description" : "Source reference for Health Interventions - exactly one of the following must be provided:\n- url (url data type): URL to retrieve HealthInterventions definition from input/ or external source\n- canonical (canonical data type): Canonical URI pointing to the HealthInterventions definition\n- instance: Inline HealthInterventions instance data",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDSCv1.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDSCv1"
      },
      "name" : "Health System Challenges",
      "description" : "Value set for Health System Challenges (Classification of Digital Health System Categories v1, 2018). Includes all 25 system category codes (A–Y).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-DAK.Persona.HealthSystemManager.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/DAK.Persona.HealthSystemManager"
      },
      "name" : "Health System Manager",
      "description" : "A professional involved in the administration and oversight of health systems.\n\nHealth system managers use DHIs to:\n- Manage health workforce information, performance, and certification (3.1)\n- Oversee supply chain, inventory, cold chain, and procurement (3.2)\n- Receive notifications of public health events (3.3)\n- Register and certify vital events — births and deaths (3.4)\n- Administer health coverage schemes, billing, payroll, and budgets (3.5)\n- Monitor and track health equipment and assets (3.6)\n- Manage health facility information and conduct assessments (3.7)\n- Manage person-centred health certificate information (3.8)\n\n**ISCO-08**: 1342 (Health services managers), 2446 (Social work professionals\nn.e.c.), 3354 (Government social benefits officials), 4311 (Accounting and\nbookkeeping clerks).\n\n**Examples**: District health officer, programme manager, supply chain officer,\nHMIS coordinator, hospital administrator, vital registration officer,\nhealth insurance administrator.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-DAK.Persona.HealthcareProvider.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/DAK.Persona.HealthcareProvider"
      },
      "name" : "Healthcare Provider",
      "description" : "A member of the health workforce who delivers health interventions. This group\nhas also been described as 'health workers' or 'healthcare workers'.\n\nHealthcare providers use DHIs to:\n- Identify and register persons for health services (2.1)\n- Manage person-centred health records (2.2)\n- Receive clinical decision support prompts and checklists (2.3)\n- Conduct telemedicine consultations and remote monitoring (2.4)\n- Communicate with supervisors, peers, and receive AI-assisted content (2.5)\n- Coordinate referrals and emergency transport (2.6)\n- Schedule and plan their clinical activities (2.7)\n- Access training content and assessments (2.8)\n- Manage prescriptions and medication adherence (2.9)\n- Order and receive laboratory and diagnostic results (2.10)\n- Verify health coverage and receive payments from individuals (2.11)\n\n**ISCO-08**: 2211 (Generalist medical practitioners), 2212 (Specialist medical\npractitioners), 2221 (Nursing professionals), 2222 (Midwifery professionals),\n3211 (Medical imaging and therapeutic equipment technicians), 3212 (Medical\nand pathology laboratory technicians), 3213 (Pharmaceutical technicians and\nassistants), 3221 (Nursing associate professionals), 3222 (Midwifery associate\nprofessionals), 3255 (Community health workers).\n\n**Examples**: Physician, nurse, midwife, clinical officer, pharmacist,\nlaboratory technician, dentist, allied health professional.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-CDHIv1Hierarchy.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/CDHIv1Hierarchy"
      },
      "name" : "Hierarchy of the Classification of Digital Health Interventions v1",
      "description" : "Mapping to represent hierarchy within the Classification of Digital Health Interventions v1.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-CDHIv2Hierarchy.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/CDHIv2Hierarchy"
      },
      "name" : "Hierarchy of the Classification of Digital Health Interventions v2",
      "description" : "Mapping to represent hierarchy within the Classification of Digital Interventions, Services and Applications in Health (CDISAH) v2.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-ISCO08.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/ISCO08"
      },
      "name" : "International Standard Classification of Occupations 2008",
      "description" : "ISCO-08 codes from the International Labour Organization official classification",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-ISCO08ValueSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/ISCO08ValueSet"
      },
      "name" : "ISCO-08 Value Set",
      "description" : "Extensible value set of ISCO-08 codes for persona classification",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGImplementationPractice.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGImplementationPractice"
      },
      "name" : "Knowledge graph L1-LIBRARY: Implementation practice",
      "description" : "A statement of how to put guidance into practice, printed in a publication whose publicationType is implementation-guidance or methodology: the handbook's \"products that are not guidelines\" (§1.9), a \"how to\" document that makes no recommendations of its own. Not a recommendation, and not a good practice statement — both are made by a guideline and approved by the GRC; this is neither. It carries no kind, direction, strength or certainty, because nothing graded it. A handbook's own \"Best practices\" lists are the typical source. Owner ruling 1b, 2026-10-12: model these as their own class, not as recommendation nodes of a new kind. statement is verbatim and is the only stored copy, as recommendation's is. identifier is used in the IRI. There is no remark: L1 3.0's remark is minted under a recommendation (its iriPattern) and hasRemark starts at one, so a remark of a practice needs L1 itself to change — proposed upstream, not patched here. Class IRI: http://smart.who.int/kg/implementation-practice.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGLibraryNode.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGLibraryNode"
      },
      "name" : "Knowledge graph L1-LIBRARY: Library node",
      "description" : "A node in the ingested library L1 is read from: a source document, a section or a block, addressed by the library's own IRI. Opaque, as L1 asserts nothing about the library's internal model; the library is upstream, so pointing at it keeps the layering rule. Class IRI: http://smart.who.int/kg/library-node.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGCertaintyVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGCertaintyVS"
      },
      "name" : "Knowledge graph L1: certainty",
      "description" : "All codes of KGCertainty.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGCertainty.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGCertainty"
      },
      "name" : "Knowledge graph L1: certainty",
      "description" : "GRADE certainty of evidence. The 2014 handbook calls it quality of evidence and names certainty as a synonym (§9.1). Rated per outcome on evidence; the overall certainty on a recommendation is the lowest across its critical outcomes (§9.6). Source: smart-kg ontology/l1/l1.json valueSets \"certainty\"; WHO handbook for guideline development (2014) §9.1, §9.5–9.6.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGChangeStatusVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGChangeStatusVS"
      },
      "name" : "Knowledge graph L1: change status",
      "description" : "All codes of KGChangeStatus.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGChangeStatus.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGChangeStatus"
      },
      "name" : "Knowledge graph L1: change status",
      "description" : "Whether this edition of a consolidated guideline introduces, updates or carries a recommendation or indicator unchanged. Printed as NEW / UPDATE tags. Source: smart-kg ontology/l1/l1.json valueSets \"change-status\"; Consolidated guidelines on person-centred HIV strategic information (2022), summary recommendations; handbook §1.7.2.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGCitation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGCitation"
      },
      "name" : "Knowledge graph L1: Citation",
      "description" : "One citation string exactly as written in a DAK artefact. A cell holding several citations yields several nodes. Content-addressed in the DAK's namespace, so one string is one node across artefacts. Where a citation was found is recorded by appearsIn (L2) and by each use edge (L2-DMN, L3 citesSource), not on the node. Class IRI: http://smart.who.int/kg/citation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGCitationKindVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGCitationKindVS"
      },
      "name" : "Knowledge graph L1: citation kind",
      "description" : "All codes of KGCitationKind.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGCitationKind.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGCitationKind"
      },
      "name" : "Knowledge graph L1: citation kind",
      "description" : "Whether a citation string names a source, or stands in for one that is missing. Source: smart-kg ontology/l1/l1.json valueSets \"citation-kind\"; IMMZ DAK indicators workbook: '[Add appropriate reference]'.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL1ClassesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL1ClassesVS"
      },
      "name" : "Knowledge graph L1: classes",
      "description" : "All codes of KGL1Classes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL1Classes.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL1Classes"
      },
      "name" : "Knowledge graph L1: classes",
      "description" : "The classes of the L1 layer of the SMART Guidelines knowledge graph. A node's `type` is one of these. Source: smart-base/L1/schemas/L1.ts (migrated from smart-kg ontology/L1/L1.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGElementTypeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGElementTypeVS"
      },
      "name" : "Knowledge graph L1: element type",
      "description" : "All codes of KGElementType.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGElementType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGElementType"
      },
      "name" : "Knowledge graph L1: element type",
      "description" : "What kind of printed block a publication element is. Source: smart-kg ontology/l1/l1.json valueSets \"element-type\"; Observed in the ANC and HIV SI guidelines and the immunization summary tables.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGEvidence.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGEvidence"
      },
      "name" : "Knowledge graph L1: Evidence",
      "description" : "One row of an evidence profile: the evidence for one outcome of one key question, with its certainty (handbook §9.2). Class IRI: http://smart.who.int/kg/evidence.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGEvidenceTypeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGEvidenceTypeVS"
      },
      "name" : "Knowledge graph L1: evidence type",
      "description" : "All codes of KGEvidenceType.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGEvidenceType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGEvidenceType"
      },
      "name" : "Knowledge graph L1: evidence type",
      "description" : "Which kind of evidence a row is, and so which scale its certainty is on: GRADE for effects, GRADE-CERQual for qualitative findings. Source: smart-kg ontology/l1/l1.json valueSets \"evidence-type\"; ANC guideline (2016) methods (GRADE and GRADE-CERQual).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGGraphDocument.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGGraphDocument"
      },
      "name" : "Knowledge graph L1: graph document",
      "description" : "One L1 knowledge-graph document: typed nodes and reified edges, provenance-pinned to the sources it was extracted from. In JSON the context element is written @context.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGGrcStatusVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGGrcStatusVS"
      },
      "name" : "Knowledge graph L1: grc status",
      "description" : "All codes of KGGrcStatus.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGGrcStatus.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGGrcStatus"
      },
      "name" : "Knowledge graph L1: grc status",
      "description" : "Whether the Guideline Review Committee approved the publication. All WHO publications containing recommendations must be approved (handbook §1.10.1); a consolidated guideline whose recommendations were all previously approved and unchanged does not require review (§1.7.2). Absent means not recorded — not the same as not reviewed. Source: smart-kg ontology/l1/l1.json valueSets \"grc-status\"; WHO handbook for guideline development (2014), §1.7.2, §1.10.1.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGHealthIntervention.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGHealthIntervention"
      },
      "name" : "Knowledge graph L1: Health intervention",
      "description" : "An intervention identified in a WHO catalogue or classification (UHC Compendium, ICHI, CDHI), digital interventions included. A peer of recommendation, not a recommendation. A DAK may draw on both. Corresponds to HealthInterventions: identifier and description correspond to HealthInterventions.id and description[x]; not a Parent because HealthInterventions requires reference 1..* DublinCore, which here is an edge (definedIn) rather than a field. Class IRI: http://smart.who.int/kg/health-intervention.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGIdentifierTypeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGIdentifierTypeVS"
      },
      "name" : "Knowledge graph L1: identifier type",
      "description" : "All codes of KGIdentifierType.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGIdentifierType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGIdentifierType"
      },
      "name" : "Knowledge graph L1: identifier type",
      "description" : "Which kind of identifier a publication carries. The first available, in this order, builds the publication IRI. url comes last: a web address is the least stable identifier and is used only for sources that have no other. Source: smart-kg ontology/l1/l1.json valueSets \"identifier-type\"; WHO IRIS practice; CDHIv2.fsh carries an ISBN.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGIndicator.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGIndicator"
      },
      "name" : "Knowledge graph L1: Indicator",
      "description" : "A WHO indicator, identified by its published reference number. Printed in several places (HIV SI 2022: summary list, Table 2.3, reference sheet) and stored once. variants is a list of {population, definition, numerator, denominator} for population-specific or level-specific forms (PRV.17, PRV.3). Corresponds to ProgramIndicator: definition, numerator, denominator and disaggregation are ProgramIndicator's elements and types (markdown); not a Parent because ProgramIndicator makes them 1..1 and an L1 indicator is recorded with what its source prints. Class IRI: http://smart.who.int/kg/indicator.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGInterventionTypeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGInterventionTypeVS"
      },
      "name" : "Knowledge graph L1: intervention type",
      "description" : "All codes of KGInterventionType.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGInterventionType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGInterventionType"
      },
      "name" : "Knowledge graph L1: intervention type",
      "description" : "DRAFT. What kind of intervention a recommendation or catalogued intervention concerns. To be aligned with the UHC Compendium's categories once checked. Source: smart-kg ontology/l1/l1.json valueSets \"intervention-type\"; WHO handbook §1.7.1 (clinical, health system, public health, diagnostic, surveillance); digital interventions per CDHI.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGKeyQuestion.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGKeyQuestion"
      },
      "name" : "Knowledge graph L1: Key question",
      "description" : "A question in PICO format, framed before the evidence search (handbook §7.1–7.4). P and C are verbatim text with codes through crossReferences; I is also joined to a catalogued intervention; O is the outcome node. Class IRI: http://smart.who.int/kg/key-question.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGOutcome.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGOutcome"
      },
      "name" : "Knowledge graph L1: Outcome",
      "description" : "An outcome a guideline group chose to judge a key question by, with its importance in this guideline (handbook §7.6). A node because evidence attaches to it and one list is shared by several questions (ANC Web annex 1). Flat: one node per specific outcome. name as first printed; aliases are the other printed forms (e.g. 'EGWG'); category is the printed group heading (e.g. 'Fetal/newborn morbidity'). Class IRI: http://smart.who.int/kg/outcome.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGOutcomeImportanceVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGOutcomeImportanceVS"
      },
      "name" : "Knowledge graph L1: outcome importance",
      "description" : "All codes of KGOutcomeImportance.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGOutcomeImportance.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGOutcomeImportance"
      },
      "name" : "Knowledge graph L1: outcome importance",
      "description" : "How the guideline development group rated an outcome on the 1–9 scale: 7–9 critical, 4–6 important. Unimportant outcomes are not carried into evidence profiles, so they have no code here. Source: smart-kg ontology/l1/l1.json valueSets \"outcome-importance\"; WHO handbook for guideline development (2014) §7.6, Fig. 7.1.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL1PredicatesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL1PredicatesVS"
      },
      "name" : "Knowledge graph L1: predicates",
      "description" : "All codes of KGL1Predicates.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL1Predicates.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL1Predicates"
      },
      "name" : "Knowledge graph L1: predicates",
      "description" : "The predicates of the L1 layer. An edge's `predicate` is one of these; which (source, target) pairs each licenses is the layer's edge table. Source: smart-base/L1/schemas/L1.ts (migrated from smart-kg ontology/L1/L1.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGPublication.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGPublication"
      },
      "name" : "Knowledge graph L1: Publication",
      "description" : "A WHO publication: a guideline of any of the handbook's types, a position paper, a summary table, a classification, implementation guidance, or a supplement. Metadata follows Dublin Core. identifiers is a list of {type, value}; type is from identifier-type, and the first of isbn, iris-handle, doi, issn, url builds the IRI, so an edition change is a new publication. issued and modified are Dublin Core. reviewBy is the handbook's review-by date (§12.5.1). sha256 pins the PDF. Derives from DublinCore (smart-base input/fsh/models/DublinCore.fsh); title, creator, publisher, language, rights are its elements. Class IRI: http://smart.who.int/kg/publication.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGPublicationElement.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGPublicationElement"
      },
      "name" : "Knowledge graph L1: Publication element",
      "description" : "One printed block: a table, a table row, a footnote, a figure, a chart, an image, a flowchart, a box or a list. It records where something is printed and exactly what is printed that no content node holds. It carries no meaning of its own; meaning lives in content nodes, joined by presentedIn. columns is the header text, verbatim. columnMap names, per column, the content field that fills it when the table is re-rendered (e.g. 'Recommendation' -> statement). cells holds only text no content node holds; a cell filled through columnMap is null. text is for unmodelled printed text such as a footnote that is not a remark. sha256 is for images. Class IRI: http://smart.who.int/kg/publication-element.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGPublicationSection.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGPublicationSection"
      },
      "name" : "Knowledge graph L1: Publication section",
      "description" : "A chapter, annex or numbered section, at any depth. Class IRI: http://smart.who.int/kg/publication-section.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGPublicationTypeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGPublicationTypeVS"
      },
      "name" : "Knowledge graph L1: publication type",
      "description" : "All codes of KGPublicationType.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGPublicationType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGPublicationType"
      },
      "name" : "Knowledge graph L1: publication type",
      "description" : "What kind of publication this is. The distinction that matters most for provenance is guideline versus not: a summary table or position paper restates recommendations made elsewhere, and a §1.9 product makes none of its own. Conflating them makes a citation resolve to the wrong authority. Source: smart-kg ontology/l1/l1.json valueSets \"publication-type\"; WHO handbook for guideline development (2014), Table 1.2 and §1.7–1.9; the BCG decision table's citation for summary-table; CDHIv2.fsh for classification.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGRecommendation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGRecommendation"
      },
      "name" : "Knowledge graph L1: Recommendation",
      "description" : "A normative statement from a WHO guideline. Kinds other than a graded recommendation (context-specific, research-only, good practice statement, no-recommendation) are the same node with a different kind. statement is verbatim and is the only stored copy. intervention, population, setting, provider and timing are verbatim slots taken from the statement, its remarks, or the enclosing caption or heading. setting absorbs the former conditionality. identifier is the published number (e.g. A.1.1), used in the IRI; sub-recommendations append their letter. Class IRI: http://smart.who.int/kg/recommendation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGRecommendationDirectionVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGRecommendationDirectionVS"
      },
      "name" : "Knowledge graph L1: recommendation direction",
      "description" : "All codes of KGRecommendationDirection.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGRecommendationDirection.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGRecommendationDirection"
      },
      "name" : "Knowledge graph L1: recommendation direction",
      "description" : "For or against. The handbook prefers \"we recommend against X\" to \"X is not recommended\", which is ambiguous between against and no recommendation (§10.6). Source: smart-kg ontology/l1/l1.json valueSets \"recommendation-direction\"; WHO handbook for guideline development (2014) §10.1, §10.6.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGRecommendationKindVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGRecommendationKindVS"
      },
      "name" : "Knowledge graph L1: recommendation kind",
      "description" : "All codes of KGRecommendationKind.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGRecommendationKind.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGRecommendationKind"
      },
      "name" : "Knowledge graph L1: recommendation kind",
      "description" : "What sort of normative statement this is. Grading is optional: ANC 2016 prints a direction ('Recommended', 'Not recommended') and no GRADE strength. A strength always needs a direction. A good practice statement and a no-recommendation carry no strength or certainty, and a no-recommendation carries no direction. Source: smart-kg ontology/l1/l1.json valueSets \"recommendation-kind\"; WHO handbook §10.4, §10.7; ANC guideline (2016) Table 1, verified; Guyatt et al. 2016 on good practice statements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGRecommendationStatusVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGRecommendationStatusVS"
      },
      "name" : "Knowledge graph L1: recommendation status",
      "description" : "All codes of KGRecommendationStatus.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGRecommendationStatus.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGRecommendationStatus"
      },
      "name" : "Knowledge graph L1: recommendation status",
      "description" : "Whether a recommendation is still in force. Recommendations in one guideline go out of date at different times (§1.7.2), and a department that doubts a recommendation's validity should say so before the update is done (§12.5.4). This is what impact analysis filters on. Source: smart-kg ontology/l1/l1.json valueSets \"recommendation-status\"; WHO handbook for guideline development (2014) §1.7.2, §12.5.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGRecommendationStrengthVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGRecommendationStrengthVS"
      },
      "name" : "Knowledge graph L1: recommendation strength",
      "description" : "All codes of KGRecommendationStrength.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGRecommendationStrength.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGRecommendationStrength"
      },
      "name" : "Knowledge graph L1: recommendation strength",
      "description" : "GRADE strength. Strength is not certainty: a strong recommendation can rest on low-certainty evidence and a conditional one on high. Record \"weak\" as conditional; the handbook treats them as synonyms (§10.4). Source: smart-kg ontology/l1/l1.json valueSets \"recommendation-strength\"; WHO handbook for guideline development (2014) §10.4.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGReferenceEntry.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGReferenceEntry"
      },
      "name" : "Knowledge graph L1: Reference entry",
      "description" : "One row of a DAK artefact's own reference list: '(1)' and the full bibliographic text and URL it stands for. Resolved once; every citation numbered to it shares the result. Class IRI: http://smart.who.int/kg/reference-entry.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGRemark.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGRemark"
      },
      "name" : "Knowledge graph L1: Remark",
      "description" : "A remark attached to a recommendation (handbook §10.6). May also be printed as a table footnote. Class IRI: http://smart.who.int/kg/remark.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGRemarkTypeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGRemarkTypeVS"
      },
      "name" : "Knowledge graph L1: remark type",
      "description" : "All codes of KGRemarkType.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGRemarkType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGRemarkType"
      },
      "name" : "Knowledge graph L1: remark type",
      "description" : "What a remark is for. Grounded in the six remarks attached to ANC recommendation A.1.1. Source: smart-kg ontology/l1/l1.json valueSets \"remark-type\"; ANC guideline (2016) p. 15; handbook §10.6, §10.8.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGResolutionStatusVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGResolutionStatusVS"
      },
      "name" : "Knowledge graph L1: resolution status",
      "description" : "All codes of KGResolutionStatus.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGResolutionStatus.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGResolutionStatus"
      },
      "name" : "Knowledge graph L1: resolution status",
      "description" : "Whether a citation string has been matched to what it cites. `ambiguous` is a legitimate terminal state — two publications with similar titles is a question for a person — and must not be collapsed to resolved. Source: smart-kg ontology/l1/l1.json valueSets \"resolution-status\"; docs/SCOPE.md.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGRowTypeVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGRowTypeVS"
      },
      "name" : "Knowledge graph L1: row type",
      "description" : "All codes of KGRowType.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGRowType.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGRowType"
      },
      "name" : "Knowledge graph L1: row type",
      "description" : "The role of a row within a table. Source: smart-kg ontology/l1/l1.json valueSets \"row-type\"; HIV SI guideline Table 2.3; ANC Table 1.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGTerminologyCode.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGTerminologyCode"
      },
      "name" : "Knowledge graph L1: Terminology code",
      "description" : "A code in an external terminology — ICD-10, ICD-11, SNOMED CT, ATC, or a WHO classification such as CDHI. CROSS-REFERENCE ONLY. It records system, code and display, and asserts NOTHING about the terminology: no hierarchy, no subsumption, no synonyms, no post-coordination. The terminology has its own authority, its own release cycle and its own tooling, and a partial copy here would be wrong within one release. Resolve meaning against the terminology server, not against this graph. Derives from Coding (FHIR R4 core datatype); system, code, display, version are its elements. Class IRI: http://smart.who.int/kg/terminology-code.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGTerminologySystemVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGTerminologySystemVS"
      },
      "name" : "Knowledge graph L1: terminology system",
      "description" : "All codes of KGTerminologySystem.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGTerminologySystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGTerminologySystem"
      },
      "name" : "Knowledge graph L1: terminology system",
      "description" : "Code systems a DAK is expected to use. An unknown system is a warning, because a misspelt system silently breaks joins across guidelines. Source: smart-kg ontology/l1/l1.json valueSets \"terminology-system\"; smart-base input/fsh/profiles/SGLogicalModel.fsh and Aliases.fsh; UHC Compendium; CDHIv2.fsh.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL1LibraryClassesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL1LibraryClassesVS"
      },
      "name" : "Knowledge graph L1Library: classes",
      "description" : "All codes of KGL1LibraryClasses.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL1LibraryClasses.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL1LibraryClasses"
      },
      "name" : "Knowledge graph L1Library: classes",
      "description" : "The classes of the L1Library layer of the SMART Guidelines knowledge graph. A node's `type` is one of these. Source: smart-base/L1/schemas/l1-library.ts (migrated from smart-kg ontology/l1-library/l1-library.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL1LibraryPredicatesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL1LibraryPredicatesVS"
      },
      "name" : "Knowledge graph L1Library: predicates",
      "description" : "All codes of KGL1LibraryPredicates.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL1LibraryPredicates.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL1LibraryPredicates"
      },
      "name" : "Knowledge graph L1Library: predicates",
      "description" : "The predicates of the L1Library layer. An edge's `predicate` is one of these; which (source, target) pairs each licenses is the layer's edge table. Source: smart-base/L1/schemas/l1-library.ts (migrated from smart-kg ontology/l1-library/l1-library.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGBpmnEvent.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGBpmnEvent"
      },
      "name" : "Knowledge graph L2-BPMN: BPMN Event",
      "description" : "A start, end or intermediate event (WHO's DAK BPMN draw intermediate throw and catch events inside sub-processes). Same connectivity argument as gateway, plus one of its own: entry and exit points are what make 'is this task reachable' and 'does this path terminate' answerable at all. Class IRI: http://smart.who.int/kg/bpmn-event.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGBpmnDefinitions.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGBpmnDefinitions"
      },
      "name" : "Knowledge graph L2-BPMN: BPMN File",
      "description" : "One BPMN file as a unit -- the `bpmn:definitions` root. Shares its IRI with the l1:external-artifact for the same file, so the component that points at it and the subgraph that opens it name one resource. Class IRI: http://smart.who.int/kg/bpmn-definitions.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGBpmnGateway.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGBpmnGateway"
      },
      "name" : "Knowledge graph L2-BPMN: BPMN Gateway",
      "description" : "A branch or merge. Included for connectivity rather than for a cross-model edge: a flow through a gateway with no node would point at nothing, and every reachability question over the process would break at the first decision point. Class IRI: http://smart.who.int/kg/bpmn-gateway.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGBpmnParticipant.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGBpmnParticipant"
      },
      "name" : "Knowledge graph L2-BPMN: BPMN Participant",
      "description" : "A pool: a role that owns part of the collaboration. The lifecycle BPMN has 8 and declares no laneSet at all, so the pool is the only unit of role assignment present and its @name is the sole link to a persona. Class IRI: http://smart.who.int/kg/bpmn-participant.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGBpmnProcess.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGBpmnProcess"
      },
      "name" : "Knowledge graph L2-BPMN: BPMN Process",
      "description" : "One `bpmn:process`. Present as a node because a participant references it by processRef, and without it the pool-to-element attribution has nothing to travel through. Class IRI: http://smart.who.int/kg/bpmn-process.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGBpmnTask.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGBpmnTask"
      },
      "name" : "Knowledge graph L2-BPMN: BPMN Task",
      "description" : "A task or sub-process. It is what a DMN usingTask href points at, what sequence flows connect, and what a DAK-level task entry describes. Sub-processes carry isSubProcess rather than getting a class of their own -- the lifecycle BPMN has exactly one. Class IRI: http://smart.who.int/kg/bpmn-task.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGGatewayDirectionVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGGatewayDirectionVS"
      },
      "name" : "Knowledge graph L2-BPMN: gateway direction",
      "description" : "All codes of KGGatewayDirection.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGGatewayDirection.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGGatewayDirection"
      },
      "name" : "Knowledge graph L2-BPMN: gateway direction",
      "description" : "BPMN 2.0's gatewayDirection. Added by the smart-base migration: smart-kg named the property without binding it. Source: smart-kg ontology/l2-bpmn/l2-bpmn.json valueSets \"gateway-direction\"; OMG BPMN 2.0.2, Gateway.gatewayDirection.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDmnDecision.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDmnDecision"
      },
      "name" : "Knowledge graph L2-DMN: DMN Decision",
      "description" : "A `dmn:decision` -- the question being answered, and the node that carries the link back to the BPMN task invoking it. A file may hold several; the BCG file holds one. Class IRI: http://smart.who.int/kg/dmn-decision.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDmnDecisionTable.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDmnDecisionTable"
      },
      "name" : "Knowledge graph L2-DMN: DMN Decision Table",
      "description" : "The table realising a decision. Separate from dmn-decision because DMN permits other expression kinds -- a literal expression, an invocation -- and collapsing the two would make the graph unable to say which was used. hitPolicy is optional and recorded as null when absent, which it is in the BCG table. DMN's default is UNIQUE, but asserting it here would put words in the author's mouth. Class IRI: http://smart.who.int/kg/dmn-decision-table.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGDmnEntryKindVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGDmnEntryKindVS"
      },
      "name" : "Knowledge graph L2-DMN: dmn entry kind",
      "description" : "All codes of KGDmnEntryKind.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGDmnEntryKind.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGDmnEntryKind"
      },
      "name" : "Knowledge graph L2-DMN: dmn entry kind",
      "description" : "Which DMN element type a column's cells are serialised as. Added by the smart-base migration from smart-kg's propertyNote, which named the two values in prose. Source: smart-kg ontology/l2-dmn/l2-dmn.json valueSets \"dmn-entry-kind\"; OMG DMN 1.3, DecisionRule.outputEntry and annotationEntry.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDmnDefinitions.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDmnDefinitions"
      },
      "name" : "Knowledge graph L2-DMN: DMN File",
      "description" : "One DMN file as a unit -- the `dmn:definitions` root. Shares its IRI with the l1:external-artifact for the same file, so the l2:decision-support-logic component that points at it and this subgraph name one resource. Class IRI: http://smart.who.int/kg/dmn-definitions.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDmnInputClause.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDmnInputClause"
      },
      "name" : "Knowledge graph L2-DMN: DMN Input Clause",
      "description" : "An input column. Its expression text is where data element names are embedded, which is the only reason this is a node rather than a property of the table. Class IRI: http://smart.who.int/kg/dmn-input-clause.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDmnOutputClause.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDmnOutputClause"
      },
      "name" : "Knowledge graph L2-DMN: DMN Output Clause",
      "description" : "An output column. The BCG table's four are Care Plan, Guidance displayed to health worker, Annotations and Reference(s). These are column DEFINITIONS in a decision table, not clinical records: no edge from this class reaches an execution artefact, and none may. serialisedAs is outputEntry or annotationEntry -- DMN splits the columns across two element types and the split is positional, so recording it is what lets a rule's cells be matched back to their columns. isReferenceColumn marks the L1 column, found by its description rather than its index. Class IRI: http://smart.who.int/kg/dmn-output-clause.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDmnRule.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDmnRule"
      },
      "name" : "Knowledge graph L2-DMN: DMN Rule",
      "description" : "One row. Its input and output cells are carried as properties, not nodes: 250 of them in the BCG table alone, none the target of a cross-model edge. What the rule needs a node for is its citation edge into L1. conditions and outputs are arrays of {clause, description, text}. DMN puts the formal expression in description and the human-readable gloss in text, and both are worth keeping -- the gloss is what a reviewer reads and the expression is what an implementer builds. Class IRI: http://smart.who.int/kg/dmn-rule.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGArtifactKindVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGArtifactKindVS"
      },
      "name" : "Knowledge graph L2: artifact kind",
      "description" : "All codes of KGArtifactKind.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGArtifactKind.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGArtifactKind"
      },
      "name" : "Knowledge graph L2: artifact kind",
      "description" : "What kind of file an external artefact is. Moved with the class from L1, where it was free text. Source: smart-kg ontology/l2/l2.json valueSets \"artifact-kind\"; Files observed in smart-base and in WHO's immunizations DAK (canonical http://smart.who.int/immunizations).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGBusinessProcess.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGBusinessProcess"
      },
      "name" : "Knowledge graph L2: Business Process Workflow",
      "description" : "DAK component 4. NOT the BPMN file -- the component that points at one. `source 1..1 uri` is that pointer, and the BPMN's interior is the l2-bpmn subgraph, reached through the external-artifact this sourcedFrom targets. `objectives 1..1 markdown` is required by BusinessProcessWorkflow.fsh and has no counterpart anywhere in BPMN XML, so it can only ever come from the FSH instance. resolutionStatus is `unresolved` on a component that something else names but no DAK declares -- an L3 artefact whose title carries the component id, for instance. The node exists so the gap is queryable and carries the referenced id and nothing else. Class IRI: http://smart.who.int/kg/business-process.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL2ClassesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL2ClassesVS"
      },
      "name" : "Knowledge graph L2: classes",
      "description" : "All codes of KGL2Classes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL2Classes.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL2Classes"
      },
      "name" : "Knowledge graph L2: classes",
      "description" : "The classes of the L2 layer of the SMART Guidelines knowledge graph. A node's `type` is one of these. Source: smart-base/L1/schemas/L2.ts (migrated from smart-kg ontology/L2/L2.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGConformanceExpectationVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGConformanceExpectationVS"
      },
      "name" : "Knowledge graph L2: conformance expectation",
      "description" : "All codes of KGConformanceExpectation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGConformanceExpectation.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGConformanceExpectation"
      },
      "name" : "Knowledge graph L2: conformance expectation",
      "description" : "The conformance verb of a requirement statement. Added by the smart-base migration from smart-kg's propertyNote, which named the four values in prose. Source: smart-kg ontology/l2/l2.json valueSets \"conformance-expectation\"; http://hl7.org/fhir/ValueSet/conformance-expectation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDataElement.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDataElement"
      },
      "name" : "Knowledge graph L2: Core Data Element",
      "description" : "DAK component 5. CoreDataElement.fsh calls itself \"the ONE EXCEPTION to allowing FHIR R4 models into the DAK LMs\": `type` is one of valueset | codesystem | conceptmap | logicalmodel and `canonical 1..1 uri` points at it. The canonical is recorded; nothing inside it is copied, because FHIR is its own query layer. `name`, `resolutionStatus` and `extractionRule` are for elements recovered from DMN input expressions rather than declared in a dictionary. A recovered element is a name that was REFERENCED, not a definition that was found, and only a resolved one may carry a canonical. Class IRI: http://smart.who.int/kg/data-element.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDecisionSupportLogic.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDecisionSupportLogic"
      },
      "name" : "Knowledge graph L2: Decision-Support Logic",
      "description" : "DAK component 6. The whole model is an id, an optional description and `source 1..1 uri` to a DMN file. Nothing about the decision itself -- which is the gap the l2-dmn subgraph fills. resolutionStatus is `unresolved` on a component that something else names but no DAK declares -- an L3 artefact whose title carries the component id, for instance. The node exists so the gap is queryable and carries the referenced id and nothing else. Class IRI: http://smart.who.int/kg/decision-support-logic.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDak.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDak"
      },
      "name" : "Knowledge graph L2: Digital Adaptation Kit",
      "description" : "The kit itself. Properties are exactly the metadata fields DAK.fsh declares and dak.json carries -- no more, so that a dak node can be produced from a real file without anything being invented. canonicalUrl equals publicationUrl on a release branch and previewUrl on a development branch, per DAK.fsh. Both are kept because which one canonicalUrl currently equals is what says whether a graph describes a release or a build. Class IRI: http://smart.who.int/kg/dak.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGExternalArtifact.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGExternalArtifact"
      },
      "name" : "Knowledge graph L2: External artefact",
      "description" : "A DAK file addressed by canonical URL: a BPMN process, a DMN decision table, a FHIR resource, a workbook. Deliberately opaque: it carries an IRI and a kind, and nothing about its interior. The L2-BPMN, L2-DMN and L3 classes that describe a file's interior elaborate this class at the same IRI. Moved here from L1 in 3.0 unchanged: a DAK file is the DAK's material, not WHO content. Class IRI: http://smart.who.int/kg/external-artifact.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGFunctionalRequirement.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGFunctionalRequirement"
      },
      "name" : "Knowledge graph L2: Functional Requirement",
      "description" : "DAK component 8, first half. The as-a/I-want/so-that shape: `activity`, `capability[x]`, `benefit[x]`, and `actor 0..* Reference(SGActor)`. The 41 committed instances use the R5 SGRequirements profile rather than this logical model, so a real instance carries `statement` entries and a userstory extension; both shapes are accommodated and `profile` records which was read. resolutionStatus is `unresolved` on a component that something else names but no DAK declares -- an L3 artefact whose title carries the component id, for instance. The node exists so the gap is queryable and carries the referenced id and nothing else. Class IRI: http://smart.who.int/kg/functional-requirement.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGPersona.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGPersona"
      },
      "name" : "Knowledge graph L2: Generic Persona",
      "description" : "DAK component 2. Grounded in GenericPersona.fsh -- title, id, description, otherNames, iscoCode bound to ISCO08ValueSet -- and in the 22 committed ActorDefinition instances that carry name, title, type and description. The two disagree about where ISCO lives, which the properties record rather than smooth over. `title` is the human-readable label a BPMN pool matches on; `name` is the CamelCase identifier a Canonical() reference matches on. They are different strings for the same persona and conflating them is precisely how the pool join breaks. GenericPersona.fsh declares `iscoCode 0..* code`, but the committed ActorDefinitions record ISCO in prose inside description, so iscoCode is usually empty and is not authoritative. Class IRI: http://smart.who.int/kg/persona.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGNonFunctionalRequirement.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGNonFunctionalRequirement"
      },
      "name" : "Knowledge graph L2: Non-Functional Requirement",
      "description" : "DAK component 8, second half. `requirement 1..1 markdown`, an optional category and classification codings. Kept separate from the functional half because the fields genuinely differ -- a non-functional requirement has no actor and no benefit. resolutionStatus is `unresolved` on a component that something else names but no DAK declares -- an L3 artefact whose title carries the component id, for instance. The node exists so the gap is queryable and carries the referenced id and nothing else. Class IRI: http://smart.who.int/kg/non-functional-requirement.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL2PredicatesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL2PredicatesVS"
      },
      "name" : "Knowledge graph L2: predicates",
      "description" : "All codes of KGL2Predicates.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL2Predicates.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL2Predicates"
      },
      "name" : "Knowledge graph L2: predicates",
      "description" : "The predicates of the L2 layer. An edge's `predicate` is one of these; which (source, target) pairs each licenses is the layer's edge table. Source: smart-base/L1/schemas/L2.ts (migrated from smart-kg ontology/L2/L2.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGProgramIndicator.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGProgramIndicator"
      },
      "name" : "Knowledge graph L2: Program Indicator",
      "description" : "DAK component 7. Named program-indicator and not `indicator` because L1 already declares an `indicator` -- one normatively defined in a publication. They are different things: this is the DAK's operational measure, and `derivedFrom` is how it points at the normative one. Collapsing them would silently merge a WHO definition with a country's implementation of it. numerator, denominator and disaggregation are all `1..1 markdown` -- prose, not a computable expression. Nothing here should be read as a calculable measure; the L3 FHIR Measure is where that would live. resolutionStatus is `unresolved` on a component that something else names but no DAK declares -- an L3 artefact whose title carries the component id, for instance. The node exists so the gap is queryable and carries the referenced id and nothing else. Class IRI: http://smart.who.int/kg/program-indicator.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGPublicationStatusVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGPublicationStatusVS"
      },
      "name" : "Knowledge graph L2: publication status",
      "description" : "All codes of KGPublicationStatus.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGPublicationStatus.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGPublicationStatus"
      },
      "name" : "Knowledge graph L2: publication status",
      "description" : "FHIR PublicationStatus, which DAK.fsh's status and every L3 resource's status take. Added by the smart-base migration: smart-kg named these properties without binding them. Source: smart-kg ontology/l2/l2.json valueSets \"publication-status\"; http://hl7.org/fhir/ValueSet/publication-status.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGRequirementStatement.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGRequirementStatement"
      },
      "name" : "Knowledge graph L2: Requirement Statement",
      "description" : "One numbered, labelled statement inside a requirement, with a conformance verb. A node rather than a property because conformance is queried across a whole DAK -- 'every SHALL in this kit, and what fulfils it' is the question requirements exist to answer. It also carries its own success criteria, so 'what would show this SHALL is met' is answerable per statement rather than per requirement. conformance is the FHIR ConformanceExpectation verb: SHALL, SHOULD, MAY or SHOULD-NOT. Across the 41 committed instances it is 155 SHALL and 15 SHOULD. successCriteria is a LIST of objects, each {key, criterion, verification}: `key` is unique within the statement (e.g. SC-1), `criterion` is a checkable sentence, and `verification` is one of test | inspection | review | analysis -- the same field name and enum as folio-assistant's requirement.ts `successCriteria`, so the two map 1:1. smart-base types it, so the shape is enforced by the schema; a statement with no successCriteria is still valid (the 170 statements committed in smart-base carry none). Class IRI: http://smart.who.int/kg/requirement-statement.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGSchedulingLogic.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGSchedulingLogic"
      },
      "name" : "Knowledge graph L2: Scheduling Logic",
      "description" : "When an intervention is due, as a DAK component. NOT declared by DAK.fsh -- it is added here because the published SOP lists Scheduling Logic as an active L2 input (spreadsheets under input/scheduling-logic), WHO's ArchiMate model declares it a BusinessObject realised by PlanDefinition, and L1's schedules needed an L2 component to reach (since L1 3.0, a recommendation's timing slot). Note that the SOP's own L3 row for scheduling is present but HTML-commented-out and there is no l3_schedulinglogic.md page, so WHO has drafted the mapping and not activated it; the L3 edge is licensed here as a deliberate departure, recorded rather than hidden. resolutionStatus is `unresolved` on a component that something else names but no DAK declares -- an L3 artefact whose title carries the component id, for instance. The node exists so the gap is queryable and carries the referenced id and nothing else. Class IRI: http://smart.who.int/kg/scheduling-logic.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGDakTask.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGDakTask"
      },
      "name" : "Knowledge graph L2: Task Entry",
      "description" : "One task of a DAK business process, as the DAK document's \"notes and annotations\" describe it: identifier, name, description, and the personas, data elements, requirements and decision tables it links to. A node rather than a property because the same task is also drawn in the BPMN file, and the two have to be joinable to be checkable against each other (`describes`). Read from a BPMN file's `dak-task-annotations/v1` sidecar (smart-base/L2-bpmn/schemas/task-annotations.ts); BusinessProcessWorkflow's `task 0..*` backbone carries the first three fields of the same thing. Class IRI: http://smart.who.int/kg/dak-task.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGTestScenario.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGTestScenario"
      },
      "name" : "Knowledge graph L2: Test Scenario",
      "description" : "DAK component 9. `feature 1..1 uri` to a Gherkin feature file, plus an optional description. The feature file's interior is not modelled: no DAK in this estate ships one yet, so a subgraph for it would have no instance to check it against. resolutionStatus is `unresolved` on a component that something else names but no DAK declares -- an L3 artefact whose title carries the component id, for instance. The node exists so the gap is queryable and carries the referenced id and nothing else. Class IRI: http://smart.who.int/kg/test-scenario.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGUserScenario.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGUserScenario"
      },
      "name" : "Knowledge graph L2: User Scenario",
      "description" : "DAK component 3. A narrative describing how personas interact. Carries `personas 0..* id`, which is the only structured link between the narrative layer and the personas it names. resolutionStatus is `unresolved` on a component that something else names but no DAK declares -- an L3 artefact whose title carries the component id, for instance. The node exists so the gap is queryable and carries the referenced id and nothing else. Class IRI: http://smart.who.int/kg/user-scenario.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGVerificationMethodVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGVerificationMethodVS"
      },
      "name" : "Knowledge graph L2: verification method",
      "description" : "All codes of KGVerificationMethod.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGVerificationMethod.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGVerificationMethod"
      },
      "name" : "Knowledge graph L2: verification method",
      "description" : "How a success criterion is verified: the classic verification methods, the same field name and codes as folio-assistant's requirement.ts `successCriteria`, so the two map 1:1. From litlfred/smart-kg main (folio-assistant#2406). Source: smart-kg ontology/l2/l2.json valueSets \"verification-method\"; folio-assistant-core schemas requirement.ts successCriteria.verification.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL2BPMNClassesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL2BPMNClassesVS"
      },
      "name" : "Knowledge graph L2BPMN: classes",
      "description" : "All codes of KGL2BPMNClasses.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL2BPMNClasses.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL2BPMNClasses"
      },
      "name" : "Knowledge graph L2BPMN: classes",
      "description" : "The classes of the L2BPMN layer of the SMART Guidelines knowledge graph. A node's `type` is one of these. Source: smart-base/L1/schemas/L2-BPMN.ts (migrated from smart-kg ontology/L2-BPMN/L2-BPMN.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL2BPMNPredicatesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL2BPMNPredicatesVS"
      },
      "name" : "Knowledge graph L2BPMN: predicates",
      "description" : "All codes of KGL2BPMNPredicates.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL2BPMNPredicates.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL2BPMNPredicates"
      },
      "name" : "Knowledge graph L2BPMN: predicates",
      "description" : "The predicates of the L2BPMN layer. An edge's `predicate` is one of these; which (source, target) pairs each licenses is the layer's edge table. Source: smart-base/L1/schemas/L2-BPMN.ts (migrated from smart-kg ontology/L2-BPMN/L2-BPMN.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL2DMNClassesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL2DMNClassesVS"
      },
      "name" : "Knowledge graph L2DMN: classes",
      "description" : "All codes of KGL2DMNClasses.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL2DMNClasses.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL2DMNClasses"
      },
      "name" : "Knowledge graph L2DMN: classes",
      "description" : "The classes of the L2DMN layer of the SMART Guidelines knowledge graph. A node's `type` is one of these. Source: smart-base/L1/schemas/L2-DMN.ts (migrated from smart-kg ontology/L2-DMN/L2-DMN.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL2DMNPredicatesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL2DMNPredicatesVS"
      },
      "name" : "Knowledge graph L2DMN: predicates",
      "description" : "All codes of KGL2DMNPredicates.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL2DMNPredicates.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL2DMNPredicates"
      },
      "name" : "Knowledge graph L2DMN: predicates",
      "description" : "The predicates of the L2DMN layer. An edge's `predicate` is one of these; which (source, target) pairs each licenses is the layer's edge table. Source: smart-base/L1/schemas/L2-DMN.ts (migrated from smart-kg ontology/L2-DMN/L2-DMN.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGActivityDefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGActivityDefinition"
      },
      "name" : "Knowledge graph L3: Activity Definition",
      "description" : "A FHIR ActivityDefinition -- the concrete act a plan's action invokes. Reached from a PlanDefinition action's `definitionCanonical`, which is a real reference rather than a convention. 3 in the immunizations IG: two cpg-immunizationactivity, one cpg-communicationactivity. Class IRI: http://smart.who.int/kg/activity-definition.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGActorDefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGActorDefinition"
      },
      "name" : "Knowledge graph L3: Actor Definition",
      "description" : "A FHIR ActorDefinition -- an L2 persona made a FHIR resource. ZERO in the immunizations IG and 22 in smart-base, which is itself worth a coverage query. The SOP names no profile for it and says one is not currently possible because SUSHI cannot profile an R5 resource in an R4 IG, and it tells authors not to assign an identifier -- so expect a bare resource and do not infer more. Class IRI: http://smart.who.int/kg/actor-definition.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL3ClassesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL3ClassesVS"
      },
      "name" : "Knowledge graph L3: classes",
      "description" : "All codes of KGL3Classes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL3Classes.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL3Classes"
      },
      "name" : "Knowledge graph L3: classes",
      "description" : "The classes of the L3 layer of the SMART Guidelines knowledge graph. A node's `type` is one of these. Source: smart-base/L1/schemas/L3.ts (migrated from smart-kg ontology/L3/L3.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGCodeSystem.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGCodeSystem"
      },
      "name" : "Knowledge graph L3: Code System",
      "description" : "A FHIR CodeSystem. The SOP says each guideline defines one guideline-level code system holding a concept for every data dictionary element -- which is what makes `code[WHO] = IMMZ.DE9` on a logical model element resolvable. 6 in the immunizations IG. The codes themselves are not copied here. Class IRI: http://smart.who.int/kg/code-system.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGConceptMap.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGConceptMap"
      },
      "name" : "Knowledge graph L3: Concept Map",
      "description" : "A FHIR ConceptMap -- one per target code system in the dictionary's terminology mappings. 8 in the immunizations IG. Records that a mapping exists; the mappings themselves belong to terminology. Class IRI: http://smart.who.int/kg/concept-map.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGCqlLibrary.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGCqlLibrary"
      },
      "name" : "Knowledge graph L3: CQL File",
      "description" : "A .cql file on disk, as opposed to the FHIR Library resource that wraps it. A node so that the mapping table's four CQL rows -- CQL Concepts and CQL Data Elements under Elements, CQL under Decision Tables, CQL IndicatorLogic under Indicators -- do not dead-end. It carries a name, a path and a hash and NOTHING about the logic: no expressions, no comment tags, no data requirements. 279 in the immunizations IG. The l3-cql subgraph is where that content belongs, and it is not built yet. No canonical, because a .cql file is not a FHIR resource and has no canonical URL. It is reached through the Library that wraps it. Class IRI: http://smart.who.int/kg/cql-library.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGLibrary.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGLibrary"
      },
      "name" : "Knowledge graph L3: Library",
      "description" : "A FHIR Library -- the resource that carries CQL. Indexed by canonical and status only. Its CONTENTS are deliberately out of scope: a future l3-cql subgraph will elaborate this same IRI, exactly as l2-bpmn elaborates a BPMN file. 279 in the immunizations IG, joined to their PlanDefinition by the `{id}Logic` suffix. Class IRI: http://smart.who.int/kg/library.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGStructureDefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGStructureDefinition"
      },
      "name" : "Knowledge graph L3: Logical Model",
      "description" : "A StructureDefinition with kind `logical` -- one data dictionary tab as a data structure. Distinct from `profile`, which constrains a FHIR resource: WHO's ArchiMate model has Logical Model realising Data Object while Profile realises Data Element, and the two are not interchangeable. 15 in the immunizations IG. Class IRI: http://smart.who.int/kg/structure-definition.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGMeasure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGMeasure"
      },
      "name" : "Knowledge graph L3: Measure",
      "description" : "A FHIR Measure -- an indicator made computable. 41 in the immunizations IG, all declaring proportion-measure-cqfm; the SOP makes the profile depend on scoring type, which is why the profile is read rather than assumed. Joined to its L2 indicator by id convention (IMMZ.IND.08 -> IMMZIND08). Class IRI: http://smart.who.int/kg/measure.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGPlanDefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGPlanDefinition"
      },
      "name" : "Knowledge graph L3: Plan Definition",
      "description" : "A FHIR PlanDefinition. The published mapping gives it two sources -- Processes and Decision Tables -- so a PlanDefinition alone does not say which it came from; the implementedBy edge does. 138 in the immunizations IG, all declaring cpg-recommendationdefinition, all decision tables. Shares its IRI with the l1:external-artifact for the same canonical. Class IRI: http://smart.who.int/kg/plan-definition.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGL3PredicatesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGL3PredicatesVS"
      },
      "name" : "Knowledge graph L3: predicates",
      "description" : "All codes of KGL3Predicates.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGL3Predicates.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGL3Predicates"
      },
      "name" : "Knowledge graph L3: predicates",
      "description" : "The predicates of the L3 layer. An edge's `predicate` is one of these; which (source, target) pairs each licenses is the layer's edge table. Source: smart-base/L1/schemas/L3.ts (migrated from smart-kg ontology/L3/L3.json).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGProfile.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGProfile"
      },
      "name" : "Knowledge graph L3: Profile",
      "description" : "A StructureDefinition constraining a FHIR resource. Separate from structure-definition for the reason above. 5 in the immunizations IG. Its internals -- differentials, element definitions, bindings -- are the clearest case of what this layer refuses to re-represent. Class IRI: http://smart.who.int/kg/profile.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGQuestionnaire.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGQuestionnaire"
      },
      "name" : "Knowledge graph L3: Questionnaire",
      "description" : "A FHIR Questionnaire -- a data-collection form over a logical model. 10 in the immunizations IG. Its `sdc-questionnaire-targetStructureMap` extension names the StructureMap that extracts it, which is a real canonical reference. The SOP states no linkId convention and none exists in the estate, so no edge is licensed on linkId. Class IRI: http://smart.who.int/kg/questionnaire.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGRequirements.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGRequirements"
      },
      "name" : "Knowledge graph L3: Requirements",
      "description" : "A FHIR Requirements resource. The ONE place the published SOP names an SG profile -- SGRequirements -- and the grain is one resource per business process holding many statements, not one per requirement. ZERO in the immunizations IG and 41 in smart-base. Class IRI: http://smart.who.int/kg/requirements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGStructureDefinitionKindVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGStructureDefinitionKindVS"
      },
      "name" : "Knowledge graph L3: structure definition kind",
      "description" : "All codes of KGStructureDefinitionKind.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGStructureDefinitionKind.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGStructureDefinitionKind"
      },
      "name" : "Knowledge graph L3: structure definition kind",
      "description" : "FHIR StructureDefinitionKind. Added by the smart-base migration: smart-kg named the property without binding it. Source: smart-kg ontology/l3/l3.json valueSets \"structure-definition-kind\"; http://hl7.org/fhir/ValueSet/structure-definition-kind.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGStructureMap.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGStructureMap"
      },
      "name" : "Knowledge graph L3: Structure Map",
      "description" : "A FHIR StructureMap. The SOP requires them in threes -- QuestionnaireResponse to logical model, logical model to resource, and a grouping map -- so a count that is not a multiple of three is worth a look. 16 .fml files in the immunizations IG. Class IRI: http://smart.who.int/kg/structure-map.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGValueSet.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGValueSet"
      },
      "name" : "Knowledge graph L3: Value Set",
      "description" : "A FHIR ValueSet. 192 in the immunizations IG -- the most numerous artefact of all. Indexed by canonical; its expansion, its compose rules and the codes it contains are terminology, which docs/SCOPE.md keeps at arm's length as firmly here as at L1. Class IRI: http://smart.who.int/kg/value-set.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KGDerivationVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KGDerivationVS"
      },
      "name" : "Knowledge graph: derivation",
      "description" : "All codes of KGDerivation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-KGDerivation.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/KGDerivation"
      },
      "name" : "Knowledge graph: derivation",
      "description" : "How a node or edge of a SMART Guidelines knowledge graph came to be. Every node and edge is exactly one of the three, and `decided` is the one a reviewer needs to find. Source: smart-kg shapes/recommendation-graph.schema.json $defs.derivation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGEdge.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGEdge"
      },
      "name" : "Knowledge graph: edge",
      "description" : "One reified statement: a predicate from a source node to a target node, with its derivation and evidence.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGEvidenceLocation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGEvidenceLocation"
      },
      "name" : "Knowledge graph: evidence location",
      "description" : "Where a node or edge came from in its source. Required on anything not mechanically derived.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGNode.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGNode"
      },
      "name" : "Knowledge graph: node",
      "description" : "One typed node of a knowledge-graph document. Its instance fields are an instance of the logical model of its class (see definedBy), e.g. KGPublication for a publication.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-KGProvenanceSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/KGProvenanceSource"
      },
      "name" : "Knowledge graph: provenance source",
      "description" : "A source a graph document was extracted from, pinned by hash.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-DAK.Persona.System.LIS.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/DAK.Persona.System.LIS"
      },
      "name" : "Laboratory Information System (LIS)",
      "description" : "A digital system that manages the complete lifecycle of laboratory test orders,\nspecimen tracking, result production, and result reporting to healthcare providers\nand persons.\n\nThe LIS supports DHIs including:\n- Transmit and track diagnostic orders (2.10.2)\n- Capture diagnostic results from digital devices (2.10.3)\n- Transmit person's diagnostic result to healthcare provider (2.10.1)\n- Transmit diagnostics result or availability of result to person(s) (1.1.4)\n- Track biological specimens (2.10.4)\n\n**Services and Application Type**: A6 — Laboratory information systems\n\n**Functional areas**: Lab requests/test ordering, sample tracking, sample\nprocessing, results reporting.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LinkIdExt.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LinkIdExt"
      },
      "name" : "LinkIdExt",
      "description" : "Smart Guidelines link identifier extension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-CDHIv1toCDHIv2.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/CDHIv1toCDHIv2"
      },
      "name" : "Mapping from CDHI v1 to CDISAH v2",
      "description" : "Mapping from the Classification of Digital Health Interventions v1 (CDHI v1, 2018)\nto the Classification of Digital Interventions, Services and Applications in Health v2\n(CDISAH v2, 2023).\n\nKey structural changes reflected in this map:\n- User group labels updated throughout (e.g. 'Clients' → 'Persons',\n  'Health workers' → 'Healthcare providers', 'Health system managers' →\n  'Health management and support personnel').\n- Civil Registration and Vital Statistics (CRVS) consolidated: six v1 codes\n  (3.4.1–3.4.6) merged into two v2 codes (3.4.1, 3.4.2).\n- Health financing section restructured: v1 3.5.1 (insurance membership) and\n  3.5.2 (billing) updated; v1 3.5.3–3.5.6 shifted by one (now 3.5.4–3.5.6 + new 3.5.3).\n- Data services (group 4) substantially revised: 4.1.1 changed scope,\n  4.3 expanded from 4 to 5 codes, 4.4 split from 1 to 3 codes, 4.5 is entirely new.\n- New v2 categories with no v1 equivalent are listed as 'unmatched' targets.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-CDSCv1toCDSCv2.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/CDSCv1toCDSCv2"
      },
      "name" : "Mapping from CDSC v1 to Services and Application Types v2",
      "description" : "Mapping from the Classification of Digital Health System Categories v1 (CDSCv1, 2018)\nto the Classification of Digital Health Services and Application Types v2 (CDSCv2, 2023).\n\nThe v1 used 25 single-letter codes (A–Y). The v2 completely restructured this into\n5 representations within the digital health enterprise architecture, each with\nalphanumeric codes (A1–A9, B1–B8, C1–C11, D1–D8, E1–E2).\n\nSeveral new v2 categories have no v1 equivalent:\nA3 (Decision support), A4 (Diagnostics), B1 (Blood bank), B3 (Health program monitoring),\nB7 (Patient administration), C4 (Facility registries), C5 (Health worker registry),\nC7 (Immunisation information), C8 (Master patient index), C9 (Product catalogues),\nC10 (Public Key directories), D1 (Analytics), D3 (Data warehouses).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-Markdown.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Markdown"
      },
      "name" : "Markdown",
      "description" : "Markdown extension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-NonFunctionalRequirement.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/NonFunctionalRequirement"
      },
      "name" : "Non-Functional Requirement (DAK)",
      "description" : "Logical Model for representing non-functional requirement from a DAK",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-DAK.Persona.Person.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/DAK.Persona.Person"
      },
      "name" : "Person (Health Service User)",
      "description" : "A member of the public who is a potential or current user of health services,\nincluding health prevention and wellness activities. Other terms used for this\ngroup include 'patient', 'client', 'individual', and 'health service user'.\nCaregivers of individuals receiving health services are also included.\n\nPersons interact with DHIs to:\n- Receive targeted (1.1) and untargeted (1.2) health communications\n- Communicate with other persons as peers (1.3)\n- Track their own health data and records (1.4)\n- Report health events and system feedback (1.5)\n- Access health information on demand including via chatbot/AI (1.6)\n- Manage their financial transactions related to health services (1.7)\n- Manage their consent for health data access and sharing (1.8)\n\n**ISCO-08**: Not applicable (non-occupational role).\n\n**Examples**: Patient, pregnant woman, caregiver, child, community member,\nhealth scheme beneficiary, person living with a chronic condition.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-Persona.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Persona"
      },
      "name" : "Persona (DAK)",
      "description" : "Logical Model for representing Personas from a DAK",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ProgramIndicator.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ProgramIndicator"
      },
      "name" : "Program Indicator (DAK)",
      "description" : "Logical Model for representing Program Indicators from a DAK. Core set of indicators that need to be aggregated for decision-making, performance metrics and subnational and national reporting.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ProgramIndicatorSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ProgramIndicatorSource"
      },
      "name" : "Program Indicator Source",
      "description" : "Source reference for Program Indicator - exactly one of the following must be provided:\n- url (url data type): URL to retrieve ProgramIndicator definition from input/ or external source\n- canonical (canonical data type): Canonical URI pointing to the ProgramIndicator definition\n- instance: Inline ProgramIndicator instance data",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.ProgrammeManager.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.ProgrammeManager"
      },
      "name" : "Programme Manager",
      "description" : "A programme manager responsible for the overall coordination and management\nof the Digital Adaptation Kit (DAK) development process. Programme managers\nlead scoping, resource allocation, timeline planning, and stakeholder engagement.\n\nThe DAK development team should be small (<10 people) and nimble. The Programme\nManager ensures the team is empowered to self-organize and manage DAK-related\nwork including collaboration with stakeholders, content development, validation,\nand publication.\n\nKey activities:\n- Define DAK scope and purpose\n- Form and coordinate the DAK development team\n- Establish development process and governance\n- Define RASCI matrix for roles and responsibilities\n- Plan sprint iterations and maintain the DAK backlog\n- Coordinate SME consultations (workshops, country visits)\n- Draft project roadmap with milestone dates\n- Assess and secure resources and budget\n\n**Source**: IG Starter Kit, L2 DAK Authoring, Section 1 \"Plan\"",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-DAK.Persona.System.SurveillanceSystem.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/DAK.Persona.System.SurveillanceSystem"
      },
      "name" : "Public Health and Disease Surveillance System",
      "description" : "A digital system for detecting, monitoring, investigating, and responding to\ndisease outbreaks and public health threats.\n\nThe surveillance system supports DHIs including:\n- Notification of public health events from point of diagnosis (3.3.1)\n- Transmit health event alerts to specific population group(s) (1.1.1)\n- Map location of health event (4.3.2)\n- Data synthesis and visualizations for outbreak response (4.1.3)\n- Automated analysis of data to generate predictions (4.1.4)\n\n**Services and Application Type**: E2 — Public health and disease surveillance systems",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.PublicationManager.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.PublicationManager"
      },
      "name" : "Publication Manager",
      "description" : "A specialist responsible for managing the FHIR Implementation Guide\nconfiguration, build process, versioning, and release publication workflow.\nPublication Managers ensure IGs are correctly configured, built, and\npublished to smart.who.int following the established publication process.\n\nKey activities:\n- Set up IG repositories from smart-ig-empty template\n- Configure sushi-config.yaml (canonical URL, package ID, dependencies)\n- Enable GitHub Pages and CI build workflows\n- Run FHIR IG Publisher builds and verify output\n- Manage semantic versioning (major.minor.patch)\n- Create publication-request.json for releases\n- Create release branches, tags, and GitHub releases\n- Monitor automated publication workflows\n- Coordinate with WHO SMART Guidelines team for smart.who.int updates\n- Manage cross-IG governance for shared artifacts\n- Reset main branch to draft status after publication\n\n**Source**: IG Starter Kit, IG Setup, IG Publication, and IG Configuration pages",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.QCReviewer.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.QCReviewer"
      },
      "name" : "Quality Control Reviewer",
      "description" : "A quality assurance specialist responsible for reviewing SMART Guidelines\nImplementation Guides for publication readiness. QC Reviewers use the\npublication checklist across L1-L4 layers, interpret QA validation reports,\nand verify artifact conformance and cross-component consistency.\n\nKey activities:\n- Run and interpret IG Publisher QA reports (qa.html)\n- Review publication checklist across L1, L2, L3, L4, and Global sections\n- Verify conformance to Shareable, Publishable, Computable, Executable profiles\n- Validate StructureMap extraction produces expected output\n- Verify CQL execution and measure calculations\n- Check cross-component consistency (personas, data elements, processes)\n- Validate all artifacts have required title, description, and mappings\n- Confirm naming conventions and reference resolution\n- Review change log completeness and versioning compliance\n\n**Source**: IG Starter Kit, QA Check page, Checklist page, Validating IG page",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-DAK.DT.IMMZ.D2.DT.BCGQuestionnaire.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/DAK.DT.IMMZ.D2.DT.BCGQuestionnaire"
      },
      "name" : "Questionnaire for IMMZ.D2 Determine required vaccination(s) if any",
      "description" : "Auto-generated questionnaire for decision table DAK.DT.IMMZ.D2.DT.BCG",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-RequirementsSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/RequirementsSource"
      },
      "name" : "Requirements Source",
      "description" : "Source reference for Requirements - exactly one of the following must be provided:\n- url (url data type): URL to retrieve Requirements definition from input/ or external source\n- canonical (canonical data type): Canonical URI pointing to the Requirements definition\n- instance: Inline Requirements instance data",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-Satisfies.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Satisfies"
      },
      "name" : "Satisfies",
      "description" : "Indicates that if the conditions for this requirement are satisified, then that it should be viewed as satisifying  the referenced requirement.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDSCv2.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDSCv2"
      },
      "name" : "Services and Application Types",
      "description" : "Value set for Services and Application Types (Classification of Digital Health Services and Application Types v2, CDISAH 2023). Includes all codes across the five architecture groups (A–E).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDSCv2.D.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDSCv2.D"
      },
      "name" : "Services and Application Types: Data Management Services",
      "description" : "Services and systems that support the collection, aggregation, storage, analysis, and exchange of health data. Group D of the Classification of Digital Health Services and Application Types v2 (CDISAH, 2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDSCv2.B.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDSCv2.B"
      },
      "name" : "Services and Application Types: Health System/Provider Administration",
      "description" : "Systems that support the administrative and managerial functions of health systems and healthcare organisations. Group B of the Classification of Digital Health Services and Application Types v2 (CDISAH, 2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDSCv2.A.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDSCv2.A"
      },
      "name" : "Services and Application Types: Point of Service",
      "description" : "Systems that facilitate the provision and delivery of healthcare services to persons at the point of care. Group A of the Classification of Digital Health Services and Application Types v2 (CDISAH, 2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDSCv2.C.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDSCv2.C"
      },
      "name" : "Services and Application Types: Registries and Directories",
      "description" : "Systems that create, maintain, and provide authoritative master records for persons, providers, facilities, products and health events. Group C of the Classification of Digital Health Services and Application Types v2 (CDISAH, 2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-CDSCv2.E.html"
      }],
      "reference" : {
        "reference" : "ValueSet/CDSCv2.E"
      },
      "name" : "Services and Application Types: Surveillance and Response",
      "description" : "Systems that support the detection, monitoring, and response to disease outbreaks and public health threats. Group E of the Classification of Digital Health Services and Application Types v2 (CDISAH, 2023).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGActorExt.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGActorExt"
      },
      "name" : "SGActorExt",
      "description" : "Smart Guidelines Actor Reference extension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGcode.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGcode"
      },
      "name" : "SGcode",
      "description" : "Smart Guidelines code extension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActivityDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActivityDefinition-SGDecisionTableGuidance.html"
      }],
      "reference" : {
        "reference" : "ActivityDefinition/SGDecisionTableGuidance"
      },
      "name" : "SGDecisionTableGuidance",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGDocumentation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGDocumentation"
      },
      "name" : "SGDocumentation",
      "description" : "Smart Guidelines Documentation extension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGMarkdown.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGMarkdown"
      },
      "name" : "SGMarkdown",
      "description" : "Smart Guidelines markdown extension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGRequirementExt.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGRequirementExt"
      },
      "name" : "SGRequirementExt",
      "description" : "Smart Guidelines Requirements extension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGString.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGString"
      },
      "name" : "SGString",
      "description" : "Smart Guidelines (required) string extension for use in a complex extension. Retired: SGUserStory now uses inline `capability` and `benefit` sub-extensions, because two slices of one extension definition cannot be told apart.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGTask.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGTask"
      },
      "name" : "SGTask",
      "description" : "Extension to reference SMART Guidelines task type",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGUserStory.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGUserStory"
      },
      "name" : "SGUserStory",
      "description" : "Smart Guidelines extension to support structured User Stories (As a `Actor` I want to `capability` so that `benefit`) extension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DecisionTableActions.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DecisionTableActions"
      },
      "name" : "Smart Guidelines Actions (columns) for Decision Tables",
      "description" : "CodeSystem for Smart Guidelines Documentation Actions for Decision Tables\"",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGActivityDefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGActivityDefinition"
      },
      "name" : "SMART Guidelines ActivityDefinition",
      "description" : "The minimum expectations for ActivityDefinition resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGActor.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGActor"
      },
      "name" : "SMART Guidelines Actor",
      "description" : "Structure and constraints for ActorDefinition resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-SGAuthoringPersonaTypes.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/SGAuthoringPersonaTypes"
      },
      "name" : "SMART Guidelines Authoring Persona Types",
      "description" : "CodeSystem for SMART Guidelines authoring persona types.\nThese represent roles involved in the authoring, review, and publication\nof SMART Guidelines and Digital Adaptation Kits, as distinct from\nthe clinical/health personas defined within a DAK.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-SGAuthoringPersonaTypesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/SGAuthoringPersonaTypesVS"
      },
      "name" : "SMART Guidelines Authoring Persona Types ValueSet",
      "description" : "ValueSet for SMART Guidelines authoring persona types",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-SGAuthoringSkills.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/SGAuthoringSkills"
      },
      "name" : "SMART Guidelines Authoring Skills",
      "description" : "CodeSystem for SMART Guidelines authoring skill capabilities.\nEach code represents a discrete skill that an authoring persona may possess.\nSkills are used to define Requirements resources as capability statements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-SGAuthoringSkillsVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/SGAuthoringSkillsVS"
      },
      "name" : "SMART Guidelines Authoring Skills ValueSet",
      "description" : "ValueSet for all SMART Guidelines authoring skill capabilities",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGBusinessProcess.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGBusinessProcess"
      },
      "name" : "SMART Guidelines Business Process",
      "description" : "Structure and constraints for Business Processes represented in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGCodeSystem.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGCodeSystem"
      },
      "name" : "SMART Guidelines CodeSystem",
      "description" : "Defines the minimum expectations for CodeSystem resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGCommunicationRequest.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGCommunicationRequest"
      },
      "name" : "SMART Guidelines Communication Request",
      "description" : "Provide communication",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGConceptMap.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGConceptMap"
      },
      "name" : "SMART Guidelines ConceptMap",
      "description" : "Defines the minimum expectations for ConceptMap resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGDecisionTable.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGDecisionTable"
      },
      "name" : "SMART Guidelines Decision Table",
      "description" : "Defines the minimum expectations for PlanDefinition resources used in SMART Guidelines which are derived from DAK Decision Tables",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DecisionTableActions.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DecisionTableActions"
      },
      "name" : "Smart Guidelines Decision Table Actions",
      "description" : "Value Set for Smart Guidelines Documentation Decision Table Actions",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DocumentationSection.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DocumentationSection"
      },
      "name" : "Smart Guidelines Documentation Section",
      "description" : "Value Set for Smart Guidelines Documentation Section to autogenerate documentation from artifacts",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DocumentationSections.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DocumentationSections"
      },
      "name" : "Smart Guidelines Documentation Section",
      "description" : "CodeSystem for Smart Guidelines Documentation Section to autogenerate documentation from artifacts",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGGraphDefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGGraphDefinition"
      },
      "name" : "SMART Guidelines GraphDefinition",
      "description" : "The minimum expectations for GraphDefinition resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGGroupDefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGGroupDefinition"
      },
      "name" : "SMART Guidelines Group Definition",
      "description" : "Structure and constraints for Group Definitions represented in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGImplementationGuide.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGImplementationGuide"
      },
      "name" : "SMART Guidelines ImplementationGuide",
      "description" : "Defines the minimum expectations for ImplementationGuide resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGLibrary.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGLibrary"
      },
      "name" : "SMART Guidelines Library",
      "description" : "Defines the minimum expectations for Library resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGLogicalModel.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGLogicalModel"
      },
      "name" : "SMART Guidelines Logical Model",
      "description" : "Defines the minimum expectations for Logical Models used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGMeasure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGMeasure"
      },
      "name" : "SMART Guidelines Measure",
      "description" : "Defines the minimum expectations for Measure resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-SGPersonaTypes.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/SGPersonaTypes"
      },
      "name" : "SMART Guidelines Persona Types",
      "description" : "CodeSystem for SMART Guidelines Persona Types",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-SGPersonaTypesVS.html"
      }],
      "reference" : {
        "reference" : "ValueSet/SGPersonaTypesVS"
      },
      "name" : "Smart Guidelines Persona Types Value Set",
      "description" : "Value Set for Smart Guidelines Persona Section to autogenerate documentation from artifacts",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGPlanDefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGPlanDefinition"
      },
      "name" : "SMART Guidelines PlanDefinition",
      "description" : "Defines the minimum expectations for PlanDefinition resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGQuestionnaire.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGQuestionnaire"
      },
      "name" : "SMART Guidelines Questionnaire",
      "description" : "Defines the minimum expectations for Questionnaire resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGRequirements.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGRequirements"
      },
      "name" : "SMART Guidelines Requirements",
      "description" : "Smart Guidelines Requirements",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGStructureDefinition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGStructureDefinition"
      },
      "name" : "SMART Guidelines StructureDefinition",
      "description" : "Defines the minimum expectations for StructureDefinition resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGStructureMap.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGStructureMap"
      },
      "name" : "SMART Guidelines StructureMap",
      "description" : "Defines the minimum expectations for StructureMap resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-SGTasks.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/SGTasks"
      },
      "name" : "SMART Guidelines Tasks",
      "description" : "CodeSystem for SMART Guidelines tasks which are specializations of the Business Process Modeling Notatiton (BPMN) tasks, which are included in this codesystem\n\nSee [BPMN Spectification](https://www.omg.org/spec/BPMN) for more info.  The descriptions were adapted from the [normative human readable documentation](https://www.omg.org/spec/BPMN/2.0.2/PDF).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGTransaction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGTransaction"
      },
      "name" : "SMART Guidelines Transaction",
      "description" : "Structure and constraints for TransactionDefinition resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SGValueSet.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SGValueSet"
      },
      "name" : "SMART Guidelines ValueSet",
      "description" : "Defines the minimum expectations for ValueSet resources used in SMART Guidelines",
      "exampleBoolean" : false,
      "groupingId" : "Conformance"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SushiConfigLogicalModel.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SushiConfigLogicalModel"
      },
      "name" : "SUSHI Configuration Logical Model",
      "description" : "Logical model defining the structure of sushi-config.yaml files used for FHIR Implementation Guide configuration. This model captures the essential metadata and configuration parameters needed for IG publishing.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.TechnicalOfficer.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.TechnicalOfficer"
      },
      "name" : "Technical Officer",
      "description" : "A health area technical officer who coordinates the work on the DAK and\nperforms first-pass review and validation of DAK content. Technical officers\nare part of the DAK development team and serve as the primary bridge between\nthe development team and the broader group of Subject Matter Experts.\n\nKey activities:\n- Coordinate DAK development work within the health programme area\n- Perform first-pass review of drafted DAK components\n- Validate that components accurately reflect L1 recommendations\n- Identify gaps, ambiguities, and alternatives in DAK content\n- Prepare agendas and questions for SME consultation meetings\n- Ensure content is software-neutral and context-appropriate\n- Spread awareness of SMART Guidelines within the department\n\n**Source**: IG Starter Kit, L2 DAK Authoring, Section 2.2 \"Validate DAK content with SMEs\"",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.Terminologist.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.Terminologist"
      },
      "name" : "Terminologist",
      "description" : "A specialist responsible for ensuring semantic interoperability of SMART\nGuidelines through proper terminology management. Terminologists manage\nthe WHO Commons dictionary, concept mappings, and ensure every data element\nis mapped to approved standard terminologies.\n\nKey activities:\n- Map data elements to WHO Commons dictionary concepts\n- Create and maintain CodeSystem resources\n- Create and maintain ValueSet resources\n- Create ConceptMap resources for cross-terminology mappings\n- Map to ICD-11, SNOMED CT, LOINC, IPS, and WHO FIC\n- Onboard new concepts into the Commons dictionary\n- Verify no duplicate or overlapping concept definitions\n- Review terminology bindings in logical models and profiles\n- Flag unapproved concepts as QA issues before publication\n\n**Source**: IG Starter Kit, Governance Concepts page;\nL3 authoring pages for CodeSystems, ValueSets, ConceptMaps",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TestScenario.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TestScenario"
      },
      "name" : "Test Scenario (DAK)",
      "description" : "Logical Model for representing Test Scenarios from a DAK. A set of test scenarios to validate an implementation of the DAK.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TestScenarioSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TestScenarioSource"
      },
      "name" : "Test Scenario Source",
      "description" : "Source reference for Test Scenario - exactly one of the following must be provided:\n- url (url data type): URL to retrieve TestScenario definition from input/ or external source\n- canonical (canonical data type): Canonical URI pointing to the TestScenario definition\n- instance: Inline TestScenario instance data",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ActorDefinition-SGAuthoring.Persona.Translator.html"
      }],
      "reference" : {
        "reference" : "ActorDefinition/SGAuthoring.Persona.Translator"
      },
      "name" : "Translator",
      "description" : "A language specialist responsible for translating SMART Guidelines\nImplementation Guide content across UN languages to support global\nadoption and adaptation.\n\nKey activities:\n- Translate IG narrative content across UN languages\n- Translate FHIR resource display names and descriptions\n- Review translated content for accuracy and clinical correctness\n- Manage .pot/.po translation template files\n- Coordinate with clinical SMEs for domain-specific terminology\n- Ensure translated examples are available for each non-abstract profile\n\n**Source**: IG Starter Kit, Checklist L4 (example resources per UN language);\nPR 288 translation skill infrastructure",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-UserScenario.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/UserScenario"
      },
      "name" : "User Scenario (DAK)",
      "description" : "Logical Model for representing User Scenarios from a DAK. Narratives that describe how the different personas may interact with each other.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-UserScenarioSource.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/UserScenarioSource"
      },
      "name" : "User Scenario Source",
      "description" : "Source reference for User Scenario - exactly one of the following must be provided:\n- url (url data type): URL to retrieve UserScenario definition from input/ or external source\n- canonical (canonical data type): Canonical URI pointing to the UserScenario definition\n- instance: Inline UserScenario instance data",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "authoring-process.html"
        }],
        "nameUrl" : "authoring-process.html",
        "title" : "Authoring Process",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "authoring-personas.html"
        }],
        "nameUrl" : "authoring-personas.html",
        "title" : "Authoring Personas",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "authoring-skills.html"
        }],
        "nameUrl" : "authoring-skills.html",
        "title" : "Authoring Skills",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "changes.html"
        }],
        "nameUrl" : "changes.html",
        "title" : "Changes",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Downloads",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "license.html"
        }],
        "nameUrl" : "license.html",
        "title" : "License",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "dak-api.html"
        }],
        "nameUrl" : "dak-api.html",
        "title" : "DAK API Documentation Hub",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
