# Can author test cases - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author test cases**

## Requirements: Can author test cases (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.AuthorTestCases | *Version*:0.3.0 |
| Draft as of 2026-11-23 | *Computable Name*:SkillAuthorTestCases |

 
Capability to create TestPlan, TestScript, and example instances for validation of L3 artifacts. 

