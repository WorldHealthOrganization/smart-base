# Can author data dictionary - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author data dictionary**

## : Can author data dictionary - XML Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorDataDictionary.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorDataDictionary.xml)

