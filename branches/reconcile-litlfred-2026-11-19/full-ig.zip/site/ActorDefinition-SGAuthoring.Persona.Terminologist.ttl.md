# Terminologist - TTL Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Terminologist**

## : Terminologist - TTL Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw ttl](ActorDefinition-SGAuthoring.Persona.Terminologist.ttl) | [Download](ActorDefinition-SGAuthoring.Persona.Terminologist.ttl)

