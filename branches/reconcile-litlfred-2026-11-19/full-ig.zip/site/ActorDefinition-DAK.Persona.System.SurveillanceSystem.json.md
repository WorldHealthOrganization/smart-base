# Public Health and Disease Surveillance System - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Public Health and Disease Surveillance System**

## : Public Health and Disease Surveillance System - JSON Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw json](ActorDefinition-DAK.Persona.System.SurveillanceSystem.json) | [Download](ActorDefinition-DAK.Persona.System.SurveillanceSystem.json)

