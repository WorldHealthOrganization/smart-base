# Can author business processes - Testing - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author business processes**

## Requirements: Can author business processes - Testing (Experimental) 

| |
| :--- |
| Draft as of 2026-11-23 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

