# Business Analyst - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Business Analyst**

## : Business Analyst - XML Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw xml](ActorDefinition-SGAuthoring.Persona.BusinessAnalyst.xml) | [Download](ActorDefinition-SGAuthoring.Persona.BusinessAnalyst.xml)

