# Quality Control Reviewer - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Quality Control Reviewer**

## : Quality Control Reviewer - JSON Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw json](ActorDefinition-SGAuthoring.Persona.QCReviewer.json) | [Download](ActorDefinition-SGAuthoring.Persona.QCReviewer.json)

