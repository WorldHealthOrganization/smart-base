# Can author plan definitions - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author plan definitions**

## : Can author plan definitions - JSON Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw json](Requirements-SGAuthoring.Skills.AuthorPlanDefinitions.json) | [Download](Requirements-SGAuthoring.Skills.AuthorPlanDefinitions.json)

