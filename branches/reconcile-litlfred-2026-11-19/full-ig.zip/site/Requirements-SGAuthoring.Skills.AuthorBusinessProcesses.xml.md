# Can author business processes - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author business processes**

## : Can author business processes - XML Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorBusinessProcesses.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorBusinessProcesses.xml)

