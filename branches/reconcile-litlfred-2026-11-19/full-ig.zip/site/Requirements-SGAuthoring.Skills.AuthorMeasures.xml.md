# Can author measures - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author measures**

## : Can author measures - XML Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorMeasures.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorMeasures.xml)

