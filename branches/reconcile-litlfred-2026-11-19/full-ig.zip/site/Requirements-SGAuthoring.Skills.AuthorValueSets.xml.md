# Can author value sets - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author value sets**

## : Can author value sets - XML Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorValueSets.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorValueSets.xml)

