# Can manage releases - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can manage releases**

## Requirements: Can manage releases (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/Requirements/SGAuthoring.Skills.ManageReleases | *Version*:0.3.0 |
| Draft as of 2026-11-23 | *Computable Name*:SkillManageReleases |

 
Capability to manage versioning, publication-request.json, release tags, and publication workflow. 

