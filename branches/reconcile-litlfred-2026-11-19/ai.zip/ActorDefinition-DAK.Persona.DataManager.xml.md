# Health Data Manager and Analyst - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health Data Manager and Analyst**

## : Health Data Manager and Analyst - XML Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw xml](ActorDefinition-DAK.Persona.DataManager.xml) | [Download](ActorDefinition-DAK.Persona.DataManager.xml)

