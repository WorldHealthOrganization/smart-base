# Can review translations - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can review translations**

## : Can review translations - XML Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw xml](Requirements-SGAuthoring.Skills.ReviewTranslations.xml) | [Download](Requirements-SGAuthoring.Skills.ReviewTranslations.xml)

