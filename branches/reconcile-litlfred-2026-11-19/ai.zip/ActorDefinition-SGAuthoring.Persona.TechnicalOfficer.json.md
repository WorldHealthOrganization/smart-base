# Technical Officer - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Technical Officer**

## : Technical Officer - JSON Representation

| |
| :--- |
| Draft as of 2026-11-23 |

[Raw json](ActorDefinition-SGAuthoring.Persona.TechnicalOfficer.json) | [Download](ActorDefinition-SGAuthoring.Persona.TechnicalOfficer.json)

