# Can author test cases - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author test cases**

## : Can author test cases - XML Representation

| |
| :--- |
| Draft as of 2026-04-02 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorTestCases.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorTestCases.xml)

