# Business Analyst - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Business Analyst**

## : Business Analyst - XML Representation

| |
| :--- |
| Draft as of 2026-04-02 |

[Raw xml](ActorDefinition-SGAuthoring.Persona.BusinessAnalyst.xml) | [Download](ActorDefinition-SGAuthoring.Persona.BusinessAnalyst.xml)

