# Clinical Subject Matter Expert - Testing - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Clinical Subject Matter Expert**

## ActorDefinition: Clinical Subject Matter Expert - Testing (Experimental) 

| |
| :--- |
| Draft as of 2026-04-02 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

