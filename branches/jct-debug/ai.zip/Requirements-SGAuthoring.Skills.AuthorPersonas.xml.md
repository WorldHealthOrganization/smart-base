# Can author personas - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author personas**

## : Can author personas - XML Representation

| |
| :--- |
| Draft as of 2026-04-02 |

[Raw xml](Requirements-SGAuthoring.Skills.AuthorPersonas.xml) | [Download](Requirements-SGAuthoring.Skills.AuthorPersonas.xml)

