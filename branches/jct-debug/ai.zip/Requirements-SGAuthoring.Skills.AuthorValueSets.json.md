# Can author value sets - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can author value sets**

## : Can author value sets - JSON Representation

| |
| :--- |
| Draft as of 2026-04-02 |

[Raw json](Requirements-SGAuthoring.Skills.AuthorValueSets.json) | [Download](Requirements-SGAuthoring.Skills.AuthorValueSets.json)

