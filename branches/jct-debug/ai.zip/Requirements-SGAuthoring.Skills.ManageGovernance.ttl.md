# Can manage governance - TTL Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can manage governance**

## : Can manage governance - TTL Representation

| |
| :--- |
| Draft as of 2026-04-02 |

[Raw ttl](Requirements-SGAuthoring.Skills.ManageGovernance.ttl) | [Download](Requirements-SGAuthoring.Skills.ManageGovernance.ttl)

