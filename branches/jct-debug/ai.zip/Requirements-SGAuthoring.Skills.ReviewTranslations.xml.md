# Can review translations - XML Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Can review translations**

## : Can review translations - XML Representation

| |
| :--- |
| Draft as of 2026-04-02 |

[Raw xml](Requirements-SGAuthoring.Skills.ReviewTranslations.xml) | [Download](Requirements-SGAuthoring.Skills.ReviewTranslations.xml)

