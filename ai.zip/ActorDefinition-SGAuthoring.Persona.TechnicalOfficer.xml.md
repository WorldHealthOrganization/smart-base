# Technical Officer - XML Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Technical Officer**

## : Technical Officer - XML Representation

| |
| :--- |
| Draft as of 2026-08-26 |

[Raw xml](ActorDefinition-SGAuthoring.Persona.TechnicalOfficer.xml) | [Download](ActorDefinition-SGAuthoring.Persona.TechnicalOfficer.xml)

