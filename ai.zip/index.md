# Home - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/base/ImplementationGuide/smart.who.int.base | *Version*:0.3.0 |
| Draft as of 2026-08-26 | *Computable Name*:Base |

### Overview

**WHO SMART Guidelines** (Standards-based, Machine-readable, Adaptive, Requirements-based, and Testable) are a set of WHO clinical guidelines that have been transformed into a computable, interoperable format. They enable countries to rapidly adopt, adapt, and implement WHO recommendations within their digital health systems by providing structured, machine-readable clinical content.

A **Digital Adaptation Kit (DAK)** is the primary artefact of WHO SMART Guidelines. It is a structured, standardised package of clinical and operational content that represents a WHO health intervention in a computable form. Each DAK contains:

* **Health interventions and recommendations** – the clinical guidance from WHO
* **Generic personas** – representative end-users and actors in the health system
* **User scenarios** – narrative descriptions of how the guidance is used in practice
* **Business processes and workflows** – step-by-step care pathways
* **Core data elements** – the data dictionary for the health domain
* **Decision-support logic** – computable clinical decision rules
* **Functional and non-functional requirements** – system capability requirements
* **Program indicators** – aggregate measures and metrics for monitoring and evaluation
* **Test scenarios** – structured tests to validate conformance

The diagram below illustrates the nine components of a WHO DAK and how they relate to one another:

Figure 1 – The nine components of a WHO Digital Adaptation Kit (DAK)
This implementation guide contains base conformance resources for use in all WHO SMART Guidelines implementation guides.

### Authoring Lifecycle

The DAK authoring lifecycle is a five-phase process spanning planning, L2 DAK authoring, L3 FHIR authoring, quality control, and publication. The BPMN 2.0 collaboration diagram below shows the end-to-end process with swimlanes for each [authoring persona](authoring-personas.md).

Figure 2 – DAK Authoring Lifecycle (BPMN 2.0). See
[Authoring Process](authoring-process.md)for details.
See the [SMART IG Starter Kit](https://smart.who.int/ig-starter-kit/) for more information on building and using WHO SMART Guidelines.

### DAK (Digital Adaptation Kit) URL Handling

For repositories that contain a `dak.json` file in the root directory, this implementation guide provides enhanced URL handling for publication and preview scenarios:

#### Publication URLs

* **WHO Repositories**: For repositories owned by `WorldHealthOrganization`, the publication URL follows the pattern `https://smart.who.int/{stub}` where `{stub}` is the repository name with any `smart-` prefix removed.
* **Other Repositories**: Use the canonical URL specified in `sushi-config.yaml` or fall back to GitHub Pages pattern.

#### Preview URLs

* **All Repositories**: Preview URLs use the GitHub Pages pattern `https://{profile}.github.io/{repo}` for current CI builds.

#### Branch-Based URL Selection

* **Release Branches** (prefixed with `release-`): Use publication URLs for canonical references and resource identifiers.
* **Development Branches**: Use preview URLs for canonical references and resource identifiers.

The DAK configuration is automatically regenerated during CI builds to ensure URLs are appropriate for the current branch context.

### Dependencies

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (smart.who.int.base.r4)](package.r4.tgz) and [R4B (smart.who.int.base.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* © International Labour Organization 2008

* [International Standard Classification of Occupations 2008](CodeSystem-ISCO08.md): [GenericPersona](StructureDefinition-GenericPersona.md) and [ISCO08ValueSet](ValueSet-ISCO08ValueSet.md)


* WHO © 2023. Some rights reserved. CC BY-NC-SA 3.0 IGO.

* [Classification of Digital Health Interventions v2](CodeSystem-CDHIv2.md): [CDHIv2](ValueSet-CDHIv2.md), [CDHIv2.1](ValueSet-CDHIv2.1.md), [CDHIv2.2](ValueSet-CDHIv2.2.md), [CDHIv2.3](ValueSet-CDHIv2.3.md) and [CDHIv2.4](ValueSet-CDHIv2.4.md)
* [Classification of Digital Health Services and Application Types v2](CodeSystem-CDSCv2.md): [CDSCv2](ValueSet-CDSCv2.md), [CDSCv2.A](ValueSet-CDSCv2.A.md)... Show 4 more, [CDSCv2.B](ValueSet-CDSCv2.B.md), [CDSCv2.C](ValueSet-CDSCv2.C.md), [CDSCv2.D](ValueSet-CDSCv2.D.md) and [CDSCv2.E](ValueSet-CDSCv2.E.md)


