# Laboratory Information System (LIS) - Testing - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Laboratory Information System (LIS)**

## ActorDefinition: Laboratory Information System (LIS) - Testing (Experimental) 

| |
| :--- |
| Draft as of 2026-03-11 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

