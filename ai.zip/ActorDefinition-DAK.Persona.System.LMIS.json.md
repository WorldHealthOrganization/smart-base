# Logistics Management Information System (LMIS) - JSON Representation - SMART Base v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Logistics Management Information System (LMIS)**

## : Logistics Management Information System (LMIS) - JSON Representation

| |
| :--- |
| Draft as of 2026-03-06 |

[Raw json](ActorDefinition-DAK.Persona.System.LMIS.json) | [Download](ActorDefinition-DAK.Persona.System.LMIS.json)

