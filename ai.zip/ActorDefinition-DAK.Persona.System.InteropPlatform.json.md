# Health Information Exchange / Interoperability Platform - JSON Representation - SMART Base v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health Information Exchange / Interoperability Platform**

## : Health Information Exchange / Interoperability Platform - JSON Representation

| |
| :--- |
| Draft as of 2026-08-26 |

[Raw json](ActorDefinition-DAK.Persona.System.InteropPlatform.json) | [Download](ActorDefinition-DAK.Persona.System.InteropPlatform.json)

